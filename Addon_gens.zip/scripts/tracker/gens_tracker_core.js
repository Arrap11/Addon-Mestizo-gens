import { world, system } from '@minecraft/server';
import { GensTrackerGeneration } from './gens_tracker_generation.js';

export class GensTracker {
    constructor() {
        this.generationTracker = new GensTrackerGeneration();
        this.performanceIntervalId = null;
        this.cleanupIntervalId = null;
        this.initializeTracking();
    }

    initializeTracking() {
        if (!world.getDynamicProperty('tracking_config')) {
            const defaultConfig = {
                trackGenerations: true,
                trackUpgrades: true,
                trackEconomy: true,
                trackPerformance: true,
                maxHistoryEntries: 10000,
                cleanupInterval: 86400000,
                detailedLogging: false
            };
            world.setDynamicProperty('tracking_config', JSON.stringify(defaultConfig));
        }

        this.startPerformanceTracking();
        this.startCleanupTasks();
    }

    startPerformanceTracking() {
        this.performanceIntervalId = system.runInterval(() => {
            this.recordPerformanceMetrics();
        }, 1200);
    }

    startCleanupTasks() {
        this.cleanupIntervalId = system.runInterval(() => {
            this.cleanupOldData();
        }, 72000);
    }

    recordGeneration(genId, amount) {
        const config = this.getTrackingConfig();
        if (!config.trackGenerations) return;

        this.generationTracker.recordGeneration(genId, amount);
        
        const timestamp = Date.now();
        const generation = {
            genId: genId,
            amount: amount,
            timestamp: timestamp,
            type: 'generation'
        };

        this.addTrackingEntry('generations', generation);
        this.updateGenerationStats(genId, amount);
    }

    recordUpgrade(genId, upgradeType, level, cost) {
        const config = this.getTrackingConfig();
        if (!config.trackUpgrades) return;

        const timestamp = Date.now();
        const upgrade = {
            genId: genId,
            upgradeType: upgradeType,
            level: level,
            cost: cost,
            timestamp: timestamp,
            type: 'upgrade'
        };

        this.addTrackingEntry('upgrades', upgrade);
        this.updateUpgradeStats(genId, upgradeType, cost);
    }

    recordEconomyTransaction(playerId, type, amount, reason) {
        const config = this.getTrackingConfig();
        if (!config.trackEconomy) return;

        const timestamp = Date.now();
        const transaction = {
            playerId: playerId,
            transactionType: type,
            amount: amount,
            reason: reason,
            timestamp: timestamp,
            type: 'economy'
        };

        this.addTrackingEntry('economy', transaction);
        this.updateEconomyStats(playerId, type, amount);
    }

    recordPerformanceMetrics() {
        const config = this.getTrackingConfig();
        if (!config.trackPerformance) return;

        const allGens = JSON.parse(world.getDynamicProperty('gens_data') || '{}');
        const activeGens = Object.values(allGens).filter(gen => 
            Date.now() - gen.lastGeneration < gen.interval * 2
        );

        const metrics = {
            totalGens: Object.keys(allGens).length,
            activeGens: activeGens.length,
            averageInterval: this.calculateAverageInterval(activeGens),
            memoryUsage: this.calculateMemoryUsage(),
            timestamp: Date.now(),
            type: 'performance'
        };

        this.addTrackingEntry('performance', metrics);
    }

    calculateAverageInterval(gens) {
        if (gens.length === 0) return 0;
        
        const totalInterval = gens.reduce((sum, gen) => sum + gen.interval, 0);
        return totalInterval / gens.length;
    }

    calculateMemoryUsage() {
        const gensData = world.getDynamicProperty('gens_data') || '{}';
        const statsData = world.getDynamicProperty('gens_stats') || '{}';
        const trackingData = world.getDynamicProperty('tracking_data') || '{}';

        return {
            gens: gensData.length,
            stats: statsData.length,
            tracking: trackingData.length,
            total: gensData.length + statsData.length + trackingData.length
        };
    }

    addTrackingEntry(category, entry) {
        const trackingData = this.getTrackingData();
        
        if (!trackingData[category]) {
            trackingData[category] = [];
        }

        trackingData[category].push(entry);
        
        const config = this.getTrackingConfig();
        if (trackingData[category].length > config.maxHistoryEntries) {
            trackingData[category] = trackingData[category].slice(-config.maxHistoryEntries);
        }

        this.saveTrackingData(trackingData);
    }

    getTrackingData() {
        try {
            return JSON.parse(world.getDynamicProperty('tracking_data') || '{}');
        } catch {
            return {};
        }
    }

    saveTrackingData(data) {
        world.setDynamicProperty('tracking_data', JSON.stringify(data));
    }

    getTrackingConfig() {
        try {
            return JSON.parse(world.getDynamicProperty('tracking_config') || '{}');
        } catch {
            return {
                trackGenerations: true,
                trackUpgrades: true,
                trackEconomy: true,
                trackPerformance: true,
                maxHistoryEntries: 10000,
                cleanupInterval: 86400000,
                detailedLogging: false
            };
        }
    }

    updateGenerationStats(genId, amount) {
        const stats = JSON.parse(world.getDynamicProperty('generation_stats') || '{}');
        
        if (!stats[genId]) {
            stats[genId] = {
                totalGenerated: 0,
                generationCount: 0,
                averageAmount: 0,
                lastGeneration: Date.now()
            };
        }

        const genStats = stats[genId];
        genStats.totalGenerated += amount;
        genStats.generationCount += 1;
        genStats.averageAmount = genStats.totalGenerated / genStats.generationCount;
        genStats.lastGeneration = Date.now();

        world.setDynamicProperty('generation_stats', JSON.stringify(stats));
    }

    updateUpgradeStats(genId, upgradeType, cost) {
        const stats = JSON.parse(world.getDynamicProperty('upgrade_stats') || '{}');
        
        if (!stats[genId]) {
            stats[genId] = {
                totalUpgrades: 0,
                totalSpent: 0,
                upgradesByType: {},
                lastUpgrade: Date.now()
            };
        }

        const genStats = stats[genId];
        genStats.totalUpgrades += 1;
        genStats.totalSpent += cost;
        genStats.upgradesByType[upgradeType] = (genStats.upgradesByType[upgradeType] || 0) + 1;
        genStats.lastUpgrade = Date.now();

        world.setDynamicProperty('upgrade_stats', JSON.stringify(stats));
    }

    updateEconomyStats(playerId, type, amount) {
        const stats = JSON.parse(world.getDynamicProperty('economy_stats') || '{}');
        
        if (!stats[playerId]) {
            stats[playerId] = {
                totalEarned: 0,
                totalSpent: 0,
                netWorth: 0,
                transactionCount: 0,
                lastTransaction: Date.now()
            };
        }

        const playerStats = stats[playerId];
        
        if (type === 'earn') {
            playerStats.totalEarned += amount;
            playerStats.netWorth += amount;
        } else if (type === 'spend') {
            playerStats.totalSpent += amount;
            playerStats.netWorth -= amount;
        }
        
        playerStats.transactionCount += 1;
        playerStats.lastTransaction = Date.now();

        world.setDynamicProperty('economy_stats', JSON.stringify(stats));
    }

    getGenerationReport(genId, timeframe = 86400000) {
        const trackingData = this.getTrackingData();
        const generations = trackingData.generations || [];
        
        const cutoffTime = Date.now() - timeframe;
        const relevantGenerations = generations.filter(gen => 
            gen.genId === genId && gen.timestamp >= cutoffTime
        );

        if (relevantGenerations.length === 0) {
            return {
                totalGenerations: 0,
                totalItems: 0,
                averageItems: 0,
                generationsPerHour: 0
            };
        }

        const totalItems = relevantGenerations.reduce((sum, gen) => sum + gen.amount, 0);
        const averageItems = totalItems / relevantGenerations.length;
        const hoursInTimeframe = timeframe / 3600000;
        const generationsPerHour = relevantGenerations.length / hoursInTimeframe;

        return {
            totalGenerations: relevantGenerations.length,
            totalItems: totalItems,
            averageItems: Math.round(averageItems * 100) / 100,
            generationsPerHour: Math.round(generationsPerHour * 100) / 100
        };
    }

    getPerformanceReport(timeframe = 3600000) {
        const trackingData = this.getTrackingData();
        const performance = trackingData.performance || [];
        
        const cutoffTime = Date.now() - timeframe;
        const relevantData = performance.filter(p => p.timestamp >= cutoffTime);

        if (relevantData.length === 0) {
            return {
                averageActiveGens: 0,
                averageMemoryUsage: 0,
                memoryTrend: 'stable'
            };
        }

        const avgActiveGens = relevantData.reduce((sum, p) => sum + p.activeGens, 0) / relevantData.length;
        const avgMemoryUsage = relevantData.reduce((sum, p) => sum + p.memoryUsage.total, 0) / relevantData.length;
        
        const firstMemory = relevantData[0].memoryUsage.total;
        const lastMemory = relevantData[relevantData.length - 1].memoryUsage.total;
        const memoryChange = ((lastMemory - firstMemory) / firstMemory) * 100;
        
        let memoryTrend = 'stable';
        if (memoryChange > 10) memoryTrend = 'increasing';
        else if (memoryChange < -10) memoryTrend = 'decreasing';

        return {
            averageActiveGens: Math.round(avgActiveGens),
            averageMemoryUsage: Math.round(avgMemoryUsage),
            memoryTrend: memoryTrend,
            memoryChangePercent: Math.round(memoryChange * 100) / 100
        };
    }

    getTopPerformers(metric = 'totalGenerated', limit = 10) {
        const generationStats = JSON.parse(world.getDynamicProperty('generation_stats') || '{}');
        
        const performers = Object.entries(generationStats)
            .map(([genId, stats]) => ({
                genId: genId,
                value: stats[metric] || 0,
                ...stats
            }))
            .sort((a, b) => b.value - a.value)
            .slice(0, limit);

        return performers;
    }

    cleanupOldData() {
        const config = this.getTrackingConfig();
        const cutoffTime = Date.now() - config.cleanupInterval;
        
        const trackingData = this.getTrackingData();
        let cleaned = false;

        Object.keys(trackingData).forEach(category => {
            const originalLength = trackingData[category].length;
            trackingData[category] = trackingData[category].filter(entry => 
                entry.timestamp >= cutoffTime
            );
            
            if (trackingData[category].length !== originalLength) {
                cleaned = true;
            }
        });

        if (cleaned) {
            this.saveTrackingData(trackingData);
        }

        return cleaned;
    }

    exportTrackingData(categories = null) {
        const trackingData = this.getTrackingData();
        
        if (categories) {
            const filtered = {};
            categories.forEach(category => {
                if (trackingData[category]) {
                    filtered[category] = trackingData[category];
                }
            });
            return filtered;
        }
        
        return trackingData;
    }

    resetTrackingData(categories = null) {
        if (categories) {
            const trackingData = this.getTrackingData();
            categories.forEach(category => {
                trackingData[category] = [];
            });
            this.saveTrackingData(trackingData);
        } else {
            world.setDynamicProperty('tracking_data', '{}');
            world.setDynamicProperty('generation_stats', '{}');
            world.setDynamicProperty('upgrade_stats', '{}');
            world.setDynamicProperty('economy_stats', '{}');
        }
    }

    generateReport(type = 'full', timeframe = 86400000) {
        const reports = {
            generation: this.generateGenerationReport(timeframe),
            performance: this.getPerformanceReport(timeframe),
            economy: this.generateEconomyReport(timeframe),
            topPerformers: this.getTopPerformers('totalGenerated', 10)
        };

        if (type === 'full') {
            return reports;
        } else {
            return reports[type] || null;
        }
    }

    generateGenerationReport(timeframe) {
        const trackingData = this.getTrackingData();
        const generations = trackingData.generations || [];
        
        const cutoffTime = Date.now() - timeframe;
        const relevantGenerations = generations.filter(gen => gen.timestamp >= cutoffTime);

        const totalGenerations = relevantGenerations.length;
        const totalItems = relevantGenerations.reduce((sum, gen) => sum + gen.amount, 0);
        
        const gensByHour = {};
        relevantGenerations.forEach(gen => {
            const hour = Math.floor(gen.timestamp / 3600000);
            gensByHour[hour] = (gensByHour[hour] || 0) + gen.amount;
        });

        const peakHour = Object.entries(gensByHour)
            .sort(([,a], [,b]) => b - a)[0];

        return {
            totalGenerations: totalGenerations,
            totalItems: totalItems,
            averagePerGeneration: totalItems / Math.max(1, totalGenerations),
            peakHourProduction: peakHour ? peakHour[1] : 0,
            hoursWithActivity: Object.keys(gensByHour).length
        };
    }

    generateEconomyReport(timeframe) {
        const trackingData = this.getTrackingData();
        const economy = trackingData.economy || [];
        
        const cutoffTime = Date.now() - timeframe;
        const relevantTransactions = economy.filter(trans => trans.timestamp >= cutoffTime);

        const totalEarned = relevantTransactions
            .filter(trans => trans.transactionType === 'earn')
            .reduce((sum, trans) => sum + trans.amount, 0);

        const totalSpent = relevantTransactions
            .filter(trans => trans.transactionType === 'spend')
            .reduce((sum, trans) => sum + trans.amount, 0);

        const uniquePlayers = new Set(relevantTransactions.map(trans => trans.playerId)).size;

        return {
            totalTransactions: relevantTransactions.length,
            totalEarned: totalEarned,
            totalSpent: totalSpent,
            netFlow: totalEarned - totalSpent,
            activePlayers: uniquePlayers,
            averageTransactionSize: relevantTransactions.length > 0 ? 
                (totalEarned + totalSpent) / relevantTransactions.length : 0
        };
    }

    setTrackingConfig(newConfig) {
        const currentConfig = this.getTrackingConfig();
        const mergedConfig = { ...currentConfig, ...newConfig };
        world.setDynamicProperty('tracking_config', JSON.stringify(mergedConfig));
        return true;
    }

    getDetailedGenStats(genId) {
        const generationStats = JSON.parse(world.getDynamicProperty('generation_stats') || '{}')[genId];
        const upgradeStats = JSON.parse(world.getDynamicProperty('upgrade_stats') || '{}')[genId];
        
        return {
            generation: generationStats || null,
            upgrades: upgradeStats || null,
            efficiency: this.calculateGenEfficiency(genId),
            trends: this.getGenTrends(genId)
        };
    }

    calculateGenEfficiency(genId) {
        const trackingData = this.getTrackingData();
        const generations = (trackingData.generations || []).filter(gen => gen.genId === genId);
        
        if (generations.length < 2) return null;

        const timeSpan = generations[generations.length - 1].timestamp - generations[0].timestamp;
        const actualGenerations = generations.length;
        
        const gen = JSON.parse(world.getDynamicProperty('gens_data') || '{}')[genId];
        if (!gen) return null;

        const expectedGenerations = Math.floor(timeSpan / gen.interval);
        const efficiency = expectedGenerations > 0 ? (actualGenerations / expectedGenerations) * 100 : 0;

        return Math.min(100, Math.round(efficiency * 100) / 100);
    }

    getGenTrends(genId, days = 7) {
        const trackingData = this.getTrackingData();
        const generations = (trackingData.generations || []).filter(gen => gen.genId === genId);
        
        const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000);
        const recentGenerations = generations.filter(gen => gen.timestamp >= cutoffTime);

        if (recentGenerations.length === 0) return null;

        const dailyProduction = {};
        recentGenerations.forEach(gen => {
            const day = Math.floor(gen.timestamp / (24 * 60 * 60 * 1000));
            dailyProduction[day] = (dailyProduction[day] || 0) + gen.amount;
        });

        const productionValues = Object.values(dailyProduction);
        const averageDaily = productionValues.reduce((sum, val) => sum + val, 0) / productionValues.length;

        const trend = this.calculateTrend(productionValues);

        return {
            averageDailyProduction: Math.round(averageDaily * 100) / 100,
            trend: trend,
            daysWithData: productionValues.length,
            peakDay: Math.max(...productionValues),
            lowestDay: Math.min(...productionValues)
        };
    }

    calculateTrend(values) {
        if (values.length < 2) return 'insufficient_data';

        const firstHalf = values.slice(0, Math.floor(values.length / 2));
        const secondHalf = values.slice(Math.floor(values.length / 2));

        const firstAvg = firstHalf.reduce((sum, val) => sum + val, 0) / firstHalf.length;
        const secondAvg = secondHalf.reduce((sum, val) => sum + val, 0) / secondHalf.length;

        const changePercent = ((secondAvg - firstAvg) / firstAvg) * 100;

        if (changePercent > 5) return 'increasing';
        if (changePercent < -5) return 'decreasing';
        return 'stable';
    }
}