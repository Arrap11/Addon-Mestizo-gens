import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { ItemStack, system, world } from '@minecraft/server';
import { EconomyCore } from '../economy/economy_core.js';
import { EconomyConfig } from '../economy/economy_config.js';

export class FormsCreator {
    constructor() {
        this.economy = new EconomyCore();
        this.config = new EconomyConfig();
    }

    async showCreateGenForm(player) {
        const form = new ActionFormData()
            .title('§6Crear Generador')
            .body('§7Selecciona el tipo de ítem:')
            .button('§8Carbón', 'textures/items/coal')
            .button('§7Hierro', 'textures/items/iron_ingot')
            .button('§6Oro', 'textures/items/gold_ingot')
            .button('§bDiamante', 'textures/items/diamond')
            .button('§aEsmeralda', 'textures/items/emerald')
            .button('§4Netherita', 'textures/items/netherite_ingot')
            .button('§8Piedra', 'textures/blocks/cobblestone')
            .button('§6Madera', 'textures/blocks/log_oak')
            .button('§cRedstone', 'textures/items/redstone')
            .button('§8Cancelar', 'textures/items/barrier');

        try {
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            if (response.selection === 9) return;
            
            const items = [
                'minecraft:coal',
                'minecraft:iron_ingot',
                'minecraft:gold_ingot',
                'minecraft:diamond',
                'minecraft:emerald',
                'minecraft:netherite_ingot',
                'minecraft:cobblestone',
                'minecraft:oak_log',
                'minecraft:redstone'
            ];
            
            const selectedItem = items[response.selection];
            system.runTimeout(() => {
                this.showRaritySelection(player, selectedItem);
            }, 5);
        } catch (error) {
            console.error("Error en showCreateGenForm:", error);
            player.sendMessage("§cError al mostrar el formulario de creación");
        }
    }

    async showRaritySelection(player, item) {
        const form = new ActionFormData()
            .title('§6Seleccionar Rareza')
            .body('§7La rareza determina la velocidad y eficiencia:')
            .button('§fComún\n§710 segundos', 'textures/items/iron_ingot')
            .button('§aPoco Común\n§78 segundos', 'textures/items/gold_ingot')
            .button('§9Raro\n§76 segundos', 'textures/items/diamond')
            .button('§5Épico\n§74 segundos', 'textures/items/emerald')
            .button('§6Legendario\n§72 segundos', 'textures/items/nether_star')
            .button('§cMítico\n§71 segundo', 'textures/items/totem')
            .button('§8Volver', 'textures/items/arrow');

        try {
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            if (response.selection === 6) {
                system.runTimeout(() => {
                    this.showCreateGenForm(player);
                }, 5);
                return;
            }
            
            const rarities = ['Común', 'Poco Común', 'Raro', 'Épico', 'Legendario', 'Mítico'];
            const selectedRarity = rarities[response.selection];
            system.runTimeout(() => {
                this.showModeSelection(player, item, selectedRarity);
            }, 5);
        } catch (error) {
            console.error("Error en showRaritySelection:", error);
            player.sendMessage("§cError al mostrar la selección de rareza");
        }
    }

    async showModeSelection(player, item, rarity) {
        const form = new ActionFormData()
            .title('§6Modo de Funcionamiento')
            .body('§7Selecciona cómo funcionará el generador:')
            .button('§2Spawn Items\n§7Deposita en contenedor abajo', 'textures/blocks/chest_front')
            .button('§4Drop Items\n§7Suelta ítems al aire', 'textures/items/arrow')
            .button('§8Volver', 'textures/items/barrier');

        try {
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            if (response.selection === 2) {
                system.runTimeout(() => {
                    this.showRaritySelection(player, item);
                }, 5);
                return;
            }
            
            const modes = ['spawn', 'drop'];
            const selectedMode = modes[response.selection];
            system.runTimeout(() => {
                this.showFinalConfiguration(player, item, rarity, selectedMode);
            }, 5);
        } catch (error) {
            console.error("Error en showModeSelection:", error);
            player.sendMessage("§cError al mostrar la selección de modo");
        }
    }

    async showFinalConfiguration(player, item, rarity, mode) {
        const baseInterval = this.config.getIntervalFromRarity(rarity);
        const baseAmount = this.config.getBaseAmountFromRarity(rarity);
        const cost = this.config.calculateGenCost(item, rarity, baseInterval, baseAmount);

        const form = new ModalFormData();
        form.title('§6Configuración Final');
        form.textField('Nombre del Generador (opcional)', 'Mi Generador');
        
        // Simplificando los sliders para evitar el error
        form.slider('Cantidad por Generación', 1, 10, 1);
        form.slider('Velocidad (segundos)', 1, 10, 5);
        
        form.toggle('Protección Anti-Griefing', true);
        form.toggle('Notificaciones de Producción', false);

        try {
            const response = await form.show(player);
            if (response.canceled) return;
            
            const formValues = response.formValues;
            const name = formValues[0];
            const amount = formValues[1];
            const speed = formValues[2];
            const protection = formValues[3];
            const notifications = formValues[4];
            
            const finalInterval = speed * 1000;
            const finalCost = Math.floor(cost * (amount / baseAmount) * (baseInterval / finalInterval));
            
            const genConfig = {
                item: item,
                rarity: rarity,
                mode: mode,
                amount: Math.floor(amount),
                interval: finalInterval,
                name: name || `Generador ${rarity}`,
                protection: Boolean(protection),
                notifications: Boolean(notifications),
                cost: finalCost
            };
            
            system.runTimeout(() => {
                this.showPurchaseConfirm(player, genConfig);
            }, 5);
        } catch (error) {
            console.error("Error en showFinalConfiguration:", error);
            player.sendMessage("§cError al mostrar la configuración final");
        }
    }

    getGeneratorBlock(itemType) {
        const blockMap = {
            'minecraft:coal': 'minecraft:coal_ore',
            'minecraft:iron_ingot': 'minecraft:iron_ore',
            'minecraft:gold_ingot': 'minecraft:gold_ore',
            'minecraft:diamond': 'minecraft:diamond_ore',
            'minecraft:emerald': 'minecraft:emerald_ore',
            'minecraft:netherite_ingot': 'minecraft:ancient_debris',
            'minecraft:cobblestone': 'minecraft:stone',
            'minecraft:oak_log': 'minecraft:oak_log',
            'minecraft:redstone': 'minecraft:redstone_ore'
        };
        return blockMap[itemType] || 'minecraft:spawner';
    }

    async showPurchaseConfirm(player, genConfig) {
        try {
            const playerMoney = this.economy.getPlayerMoney(player);
            const canAfford = playerMoney >= genConfig.cost;
            
            const itemValue = this.config.getItemValue(genConfig.item);
            const valuePerGen = itemValue * genConfig.amount;
            const valuePerHour = Math.floor((valuePerGen * 3600000) / genConfig.interval);
            
            const details = `§7Generador: §e${genConfig.name}
§7Ítem: §f${genConfig.item.replace('minecraft:', '')}
§7Rareza: §${this.getRarityColor(genConfig.rarity)}${genConfig.rarity}
§7Modo: §f${genConfig.mode === 'spawn' ? 'Spawn (cofre abajo)' : 'Drop (aire)'}

§7=== Producción ===
§7Cantidad: §a${genConfig.amount} items
§7Velocidad: §b${genConfig.interval / 1000} segundos
§7Valor por gen: §6${this.economy.formatMoney(valuePerGen)}
§7Valor por hora: §6${this.economy.formatMoney(valuePerHour)}

§7Costo: §6${this.economy.formatMoney(genConfig.cost)}
§7Tu dinero: §e${this.economy.formatMoney(playerMoney)}`;

            const form = new MessageFormData()
                .title('§6Confirmar Compra')
                .body(details)
                .button1(canAfford ? '§2Comprar Generador' : '§cSin Dinero')
                .button2('§8Cancelar');
                
            const response = await form.show(player);
            if (response.canceled || response.selection !== 0) return;
            
            if (!canAfford) {
                player.sendMessage('§cNo tienes suficiente dinero para comprar este generador');
                return;
            }
            
            if (this.economy.removeMoney(player, genConfig.cost)) {
                player.setDynamicProperty('temp_gen_config', JSON.stringify(genConfig));
                
                const generatorBlock = this.getGeneratorBlock(genConfig.item);
                const spawner = new ItemStack(generatorBlock, 1);
                spawner.nameTag = `§${this.getRarityColor(genConfig.rarity)}${genConfig.name}`;
                
                const loreArray = [
                    `§7Ítem: §f${genConfig.item.replace('minecraft:', '')}`,
                    `§7Rareza: §${this.getRarityColor(genConfig.rarity)}${genConfig.rarity}`,
                    `§7Modo: §f${genConfig.mode === 'spawn' ? 'Spawn' : 'Drop'}`,
                    `§7Cantidad: §a${genConfig.amount}`,
                    `§7Velocidad: §b${genConfig.interval / 1000}s`,
                    `§7Valor/hora: §6${this.economy.formatMoney(valuePerHour)}`,
                    '',
                    '§6⚡ GENERADOR ACTIVO ⚡',
                    '§7Coloca este bloque para activar'
                ];
                
                spawner.setLore(loreArray);
                
                const inventory = player.getComponent('inventory');
                if (inventory && inventory.container) {
                    inventory.container.addItem(spawner);
                    player.sendMessage('§aGenerador comprado exitosamente');
                    player.sendMessage('§7Coloca el bloque para activarlo');
                    
                    if (genConfig.mode === 'spawn') {
                        player.sendMessage('§7§oRequiere cofre/tolva abajo para funcionar');
                    }
                    
                    console.log(`Player ${player.name} purchased generator: ${genConfig.item} (${genConfig.rarity})`);
                } else {
                    this.economy.addMoney(player, genConfig.cost);
                    player.sendMessage('§cError: No se pudo agregar el generador al inventario');
                }
            }
        } catch (error) {
            console.error("Error en showPurchaseConfirm:", error);
            player.sendMessage("§cError al procesar la compra");
        }
    }

    getRarityColor(rarity) {
        const colors = {
            'Común': 'f',
            'Poco Común': 'a',
            'Raro': '9',
            'Épico': '5',
            'Legendario': '6',
            'Mítico': 'c'
        };
        return colors[rarity] || 'f';
    }

    async showItemSelector(player, callback) {
        try {
            const items = this.config.getAvailableItems();
            const form = new ActionFormData()
                .title('§6Seleccionar Ítem')
                .body('§7Elige el ítem que generará:');
                
            items.forEach(item => {
                const displayName = item.replace('minecraft:', '').replace('_', ' ');
                form.button(`§f${displayName}`, `textures/items/${item.replace('minecraft:', '')}`);
            });
            
            const response = await form.show(player);
            if (!response.canceled && response.selection !== undefined) {
                callback(items[response.selection]);
            }
        } catch (error) {
            console.error("Error en showItemSelector:", error);
            player.sendMessage("§cError al mostrar el selector de ítems");
        }
    }

    async showCustomGenCreator(player) {
        const form = new ModalFormData();
        form.title('§6Crear Generador Personalizado');
        form.textField('ID del Ítem', 'minecraft:diamond');
        form.dropdown('Rareza', this.config.getRarities(), 0);
        form.dropdown('Modo', ['Spawn', 'Drop'], 0);
        form.slider('Cantidad Base', 1, 50, 1);
        form.slider('Intervalo (segundos)', 1, 60, 5);
        form.textField('Nombre Personalizado', 'Mi Generador Custom');
        form.toggle('Activar Sistema de Energía', false);
        form.slider('Energía Requerida', 1, 100, 10);

        try {
            const response = await form.show(player);
            if (response.canceled) return;
            
            const formValues = response.formValues;
            const itemId = formValues[0];
            const rarityIndex = formValues[1];
            const modeIndex = formValues[2];
            const amount = formValues[3];
            const intervalSec = formValues[4];
            const name = formValues[5];
            const useEnergy = formValues[6];
            const energyCost = formValues[7];
            
            const interval = intervalSec * 1000;
            
            const genConfig = {
                item: itemId,
                rarity: this.config.getRarities()[rarityIndex],
                mode: modeIndex === 0 ? 'spawn' : 'drop',
                amount: Math.floor(amount),
                interval: interval,
                name: name || 'Generador Custom',
                useEnergy: Boolean(useEnergy),
                energyCost: useEnergy ? Math.floor(energyCost) : 0,
                cost: 0
            };
            
            const validation = this.config.validateGenConfig(genConfig);
            if (!validation.valid) {
                player.sendMessage(`§cError: ${validation.error}`);
                return;
            }
            
            player.setDynamicProperty('temp_gen_config', JSON.stringify(genConfig));
            
            const generatorBlock = this.getGeneratorBlock(genConfig.item);
            const spawner = new ItemStack(generatorBlock, 1);
            spawner.nameTag = `§${this.getRarityColor(genConfig.rarity)}${genConfig.name}`;
            
            const loreArray = [
                `§7Ítem: §f${genConfig.item.replace('minecraft:', '')}`,
                `§7Rareza: §${this.getRarityColor(genConfig.rarity)}${genConfig.rarity}`,
                `§7Modo: §f${genConfig.mode === 'spawn' ? 'Spawn' : 'Drop'}`,
                `§7Cantidad: §a${genConfig.amount}`,
                `§7Velocidad: §b${genConfig.interval / 1000}s`,
                '',
                '§6⚡ GENERADOR PERSONALIZADO ⚡',
                '§7Coloca para activar'
            ];
            
            if (genConfig.useEnergy) {
                loreArray.splice(-3, 0, `§7Energía: §c${genConfig.energyCost}`);
            }
            
            spawner.setLore(loreArray);
            
            const inventory = player.getComponent('inventory');
            if (inventory && inventory.container) {
                inventory.container.addItem(spawner);
                player.sendMessage('§aGenerador personalizado creado');
                console.log(`Custom generator created by ${player.name}: ${genConfig.item}`);
            }
        } catch (error) {
            console.error("Error en showCustomGenCreator:", error);
            player.sendMessage("§cError al crear generador personalizado");
        }
    }

    static testModalForm(player) {
        const form = new ModalFormData();
        form.title('§aTest Form');
        form.textField('Campo Texto', 'placeholder');
        form.slider('Slider Test', 0, 100, 50);
        form.toggle('Toggle Test', true);
        form.dropdown('Dropdown Test', ['Opción 1', 'Opción 2'], 0);
        
        form.show(player).then((response) => {
            if (!response.canceled) {
                player.sendMessage('§aFormulario de prueba funcionando correctamente');
                console.log('Form values:', response.formValues);
            }
        }).catch((error) => {
            console.error("Error en formulario de prueba:", error);
            player.sendMessage('§cError en formulario de prueba');
        });
    }
}