import { world } from '@minecraft/server';
import { EconomyConfig } from './economy_config.js';

export class EconomyCore {
    constructor() {
        this.config = new EconomyConfig();
        this.initializeScoreboard();
    }

    initializeScoreboard() {
        try {
            let moneyObjective = world.scoreboard.getObjective('money');
            if (!moneyObjective) {
                moneyObjective = world.scoreboard.addObjective('money', 'Dinero');
                console.log('[Scripting][gens]-Money scoreboard created successfully');
            }
        } catch (error) {
            console.error(`[Scripting][gens]-Failed to initialize money scoreboard: ${error.message}`);
        }
    }

    getPlayerMoney(player) {
        try {
            const moneyObjective = world.scoreboard.getObjective('money');
            if (!moneyObjective) {
                console.error('[Scripting][gens]-Money scoreboard not found');
                return 0;
            }
            return moneyObjective.getScore(player) || 0;
        } catch (error) {
            console.error(`[Scripting][gens]-Failed to get money for player ${player.name}: ${error.message}`);
            return 0;
        }
    }

    setPlayerMoney(player, amount) {
        try {
            const moneyObjective = world.scoreboard.getObjective('money');
            if (!moneyObjective) {
                console.error('[Scripting][gens]-Money scoreboard not found');
                return false;
            }
            moneyObjective.setScore(player, Math.max(0, amount));
            console.log(`[Scripting][gens]-Set money for player ${player.name} to ${amount}`);
            return true;
        } catch (error) {
            console.error(`[Scripting][gens]-Failed to set money for player ${player.name}: ${error.message}`);
            return false;
        }
    }

    addMoney(player, amount) {
        const current = this.getPlayerMoney(player);
        const newAmount = current + amount;
        if (this.setPlayerMoney(player, newAmount)) {
            console.log(`[Scripting][gens]-Added ${amount} money to player ${player.name} (${current} -> ${newAmount})`);
            return true;
        }
        return false;
    }

    removeMoney(player, amount) {
        const current = this.getPlayerMoney(player);
        if (current >= amount) {
            const newAmount = current - amount;
            if (this.setPlayerMoney(player, newAmount)) {
                console.log(`[Scripting][gens]-Removed ${amount} money from player ${player.name} (${current} -> ${newAmount})`);
                return true;
            }
        } else {
            console.warn(`[Scripting][gens]-Player ${player.name} attempted to spend ${amount} but only has ${current}`);
        }
        return false;
    }

    canAfford(player, amount) {
        return this.getPlayerMoney(player) >= amount;
    }

    formatMoney(amount) {
        if (amount >= 1000000000) {
            return `${(amount / 1000000000).toFixed(1)}B`;
        } else if (amount >= 1000000) {
            return `${(amount / 1000000).toFixed(1)}M`;
        } else if (amount >= 1000) {
            return `${(amount / 1000).toFixed(1)}K`;
        }
        return amount.toString();
    }

    getUpgradeCost(currentLevel, upgradeType) {
        const baseCost = this.config.getUpgradeCost(upgradeType);
        return Math.floor(baseCost * Math.pow(1.5, currentLevel));
    }

    processUpgrade(player, genId, upgradeType) {
        const gen = this.getGenById(genId);
        if (!gen) {
            console.error(`[Scripting][gens]-Upgrade failed: Generator ${genId} not found`);
            return false;
        }

        const cost = this.getUpgradeCost(gen[upgradeType + '_level'] || 0, upgradeType);
        
        if (this.removeMoney(player, cost)) {
            this.upgradeGen(genId, upgradeType);
            console.log(`[Scripting][gens]-Player ${player.name} upgraded ${upgradeType} for generator ${genId} - Cost: ${cost}`);
            return true;
        }
        console.warn(`[Scripting][gens]-Player ${player.name} failed to upgrade ${upgradeType} for generator ${genId} - Insufficient funds (needed: ${cost}, has: ${this.getPlayerMoney(player)})`);
        return false;
    }

    getGenById(genId) {
        try {
            const allGens = JSON.parse(world.getDynamicProperty('gens_data') || '{}');
            return allGens[genId] || null;
        } catch (error) {
            console.error(`[Scripting][gens]-Failed to get generator ${genId}: ${error.message}`);
            return null;
        }
    }

    upgradeGen(genId, upgradeType) {
        try {
            const allGens = JSON.parse(world.getDynamicProperty('gens_data') || '{}');
            const gen = allGens[genId];
            
            if (gen) {
                const currentLevel = gen[upgradeType + '_level'] || 0;
                gen[upgradeType + '_level'] = currentLevel + 1;
                
                switch (upgradeType) {
                    case 'speed':
                        gen.interval = Math.max(1000, gen.interval * 0.9);
                        console.log(`[Scripting][gens]-Speed upgrade applied to generator ${genId}: interval now ${gen.interval}ms`);
                        break;
                    case 'amount':
                        gen.amount = Math.floor(gen.amount * 1.25);
                        console.log(`[Scripting][gens]-Amount upgrade applied to generator ${genId}: amount now ${gen.amount}`);
                        break;
                    case 'efficiency':
                        gen.multiplier = (gen.multiplier || 1) * 1.1;
                        console.log(`[Scripting][gens]-Efficiency upgrade applied to generator ${genId}: multiplier now ${gen.multiplier.toFixed(2)}`);
                        break;
                }
                
                world.setDynamicProperty('gens_data', JSON.stringify(allGens));
                return true;
            }
        } catch (error) {
            console.error(`[Scripting][gens]-Failed to upgrade generator ${genId}: ${error.message}`);
        }
        return false;
    }

    calculatePrestigeCost(gen) {
        const prestigeLevel = gen.prestige_level || 0;
        return Math.floor(1000000 * Math.pow(10, prestigeLevel));
    }

    prestigeGen(player, genId) {
        const gen = this.getGenById(genId);
        if (!gen) {
            console.error(`[Scripting][gens]-Prestige failed: Generator ${genId} not found`);
            return false;
        }

        const cost = this.calculatePrestigeCost(gen);
        
        if (this.removeMoney(player, cost)) {
            try {
                const allGens = JSON.parse(world.getDynamicProperty('gens_data') || '{}');
                const targetGen = allGens[genId];
                
                targetGen.prestige_level = (targetGen.prestige_level || 0) + 1;
                targetGen.speed_level = 0;
                targetGen.amount_level = 0;
                targetGen.efficiency_level = 0;
                targetGen.multiplier = (targetGen.prestige_level + 1) * 2;
                
                world.setDynamicProperty('gens_data', JSON.stringify(allGens));
                console.log(`[Scripting][gens]-Player ${player.name} prestiged generator ${genId} to level ${targetGen.prestige_level} - Cost: ${cost}`);
                return true;
            } catch (error) {
                console.error(`[Scripting][gens]-Failed to prestige generator ${genId}: ${error.message}`);
                this.addMoney(player, cost);
            }
        }
        console.warn(`[Scripting][gens]-Player ${player.name} failed to prestige generator ${genId} - Insufficient funds (needed: ${cost}, has: ${this.getPlayerMoney(player)})`);
        return false;
    }

    getMoneyScoreboardDisplay(player) {
        const money = this.getPlayerMoney(player);
        return `§6${this.formatMoney(money)} monedas`;
    }

    transferMoney(fromPlayer, toPlayer, amount) {
        if (this.canAfford(fromPlayer, amount)) {
            if (this.removeMoney(fromPlayer, amount)) {
                if (this.addMoney(toPlayer, amount)) {
                    console.log(`[Scripting][gens]-Money transfer: ${fromPlayer.name} -> ${toPlayer.name} (${amount})`);
                    return true;
                } else {
                    this.addMoney(fromPlayer, amount);
                    console.error(`[Scripting][gens]-Money transfer failed: Could not add money to ${toPlayer.name}`);
                }
            }
        }
        return false;
    }
}