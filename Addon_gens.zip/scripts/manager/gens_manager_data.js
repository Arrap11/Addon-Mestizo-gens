import { world } from '@minecraft/server';

export class GensManagerData {
    constructor() {
        this.initializeData();
    }

    initializeData() {
        if (!world.getDynamicProperty('gens_data')) {
            world.setDynamicProperty('gens_data', '{}');
        }
        if (!world.getDynamicProperty('gens_stats')) {
            world.setDynamicProperty('gens_stats', '{}');
        }
        if (!world.getDynamicProperty('global_stats')) {
            world.setDynamicProperty('global_stats', JSON.stringify({
                totalGensCreated: 0,
                totalItemsGenerated: 0,
                totalValueGenerated: 0
            }));
        }
    }

    saveGen(genId, genData) {
        const allGens = this.getAllGens();
        allGens[genId] = genData;
        world.setDynamicProperty('gens_data', JSON.stringify(allGens));
    }

    getGen(genId) {
        const allGens = this.getAllGens();
        return allGens[genId] || null;
    }

    getAllGens() {
        try {
            return JSON.parse(world.getDynamicProperty('gens_data') || '{}');
        } catch {
            return {};
        }
    }

    removeGen(genId) {
        const allGens = this.getAllGens();
        delete allGens[genId];
        world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        
        const allStats = this.getAllStats();
        delete allStats[genId];
        world.setDynamicProperty('gens_stats', JSON.stringify(allStats));
    }

    getGenByLocation(location) {
        const allGens = this.getAllGens();
        
        for (const genId in allGens) {
            const gen = allGens[genId];
            if (gen.location.x === location.x && 
                gen.location.y === location.y && 
                gen.location.z === location.z) {
                return gen;
            }
        }
        return null;
    }

    updateGenProperty(genId, property, value) {
        const allGens = this.getAllGens();
        if (allGens[genId]) {
            allGens[genId][property] = value;
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
            return true;
        }
        return false;
    }

    getAllStats() {
        try {
            return JSON.parse(world.getDynamicProperty('gens_stats') || '{}');
        } catch {
            return {};
        }
    }

    saveGenStats(genId, stats) {
        const allStats = this.getAllStats();
        allStats[genId] = stats;
        world.setDynamicProperty('gens_stats', JSON.stringify(allStats));
    }

    getGenStats(genId) {
        const allStats = this.getAllStats();
        return allStats[genId] || {
            totalItems: 0,
            totalValue: 0,
            generationCount: 0,
            createdAt: Date.now(),
            lastActive: Date.now()
        };
    }

    updateGenStats(genId, itemsGenerated, value) {
        const stats = this.getGenStats(genId);
        stats.totalItems += itemsGenerated;
        stats.totalValue += value;
        stats.generationCount += 1;
        stats.lastActive = Date.now();
        
        this.saveGenStats(genId, stats);
        this.updateGlobalStats(itemsGenerated, value);
    }

    getGlobalStats() {
        try {
            return JSON.parse(world.getDynamicProperty('global_stats') || '{}');
        } catch {
            return {
                totalGensCreated: 0,
                totalItemsGenerated: 0,
                totalValueGenerated: 0
            };
        }
    }

    updateGlobalStats(itemsGenerated, value) {
        const globalStats = this.getGlobalStats();
        globalStats.totalItemsGenerated += itemsGenerated;
        globalStats.totalValueGenerated += value;
        world.setDynamicProperty('global_stats', JSON.stringify(globalStats));
    }

    incrementGensCreated() {
        const globalStats = this.getGlobalStats();
        globalStats.totalGensCreated += 1;
        world.setDynamicProperty('global_stats', JSON.stringify(globalStats));
    }

    getPlayerGens(playerName) {
        const allGens = this.getAllGens();
        const playerGens = {};
        
        for (const genId in allGens) {
            if (allGens[genId].owner === playerName) {
                playerGens[genId] = allGens[genId];
            }
        }
        
        return playerGens;
    }

    getGensByDimension(dimensionId) {
        const allGens = this.getAllGens();
        const dimensionGens = {};
        
        for (const genId in allGens) {
            if (allGens[genId].dimension === dimensionId) {
                dimensionGens[genId] = allGens[genId];
            }
        }
        
        return dimensionGens;
    }

    cleanupInvalidGens() {
        const allGens = this.getAllGens();
        const validGens = {};
        let cleaned = false;
        
        for (const genId in allGens) {
            const gen = allGens[genId];
            
            try {
                const dimension = world.getDimension(gen.dimension);
                const block = dimension.getBlock(gen.location);
                
                if (block && block.typeId === 'minecraft:spawner') {
                    validGens[genId] = gen;
                } else {
                    cleaned = true;
                }
            } catch {
                cleaned = true;
            }
        }
        
        if (cleaned) {
            world.setDynamicProperty('gens_data', JSON.stringify(validGens));
            
            const allStats = this.getAllStats();
            const validStats = {};
            
            for (const genId in validGens) {
                if (allStats[genId]) {
                    validStats[genId] = allStats[genId];
                }
            }
            
            world.setDynamicProperty('gens_stats', JSON.stringify(validStats));
        }
        
        return cleaned;
    }

    backupData() {
        const timestamp = Date.now();
        const backupData = {
            gens: this.getAllGens(),
            stats: this.getAllStats(),
            globalStats: this.getGlobalStats(),
            timestamp: timestamp
        };
        
        world.setDynamicProperty(`backup_${timestamp}`, JSON.stringify(backupData));
        
        const backups = this.getBackupList();
        backups.push(timestamp);
        
        if (backups.length > 5) {
            const oldestBackup = backups.shift();
            world.setDynamicProperty(`backup_${oldestBackup}`, undefined);
        }
        
        world.setDynamicProperty('backup_list', JSON.stringify(backups));
        
        return timestamp;
    }

    getBackupList() {
        try {
            return JSON.parse(world.getDynamicProperty('backup_list') || '[]');
        } catch {
            return [];
        }
    }

    restoreBackup(timestamp) {
        try {
            const backupData = JSON.parse(world.getDynamicProperty(`backup_${timestamp}`) || '{}');
            
            if (backupData.gens) {
                world.setDynamicProperty('gens_data', JSON.stringify(backupData.gens));
            }
            
            if (backupData.stats) {
                world.setDynamicProperty('gens_stats', JSON.stringify(backupData.stats));
            }
            
            if (backupData.globalStats) {
                world.setDynamicProperty('global_stats', JSON.stringify(backupData.globalStats));
            }
            
            return true;
        } catch {
            return false;
        }
    }

    exportData() {
        return {
            gens: this.getAllGens(),
            stats: this.getAllStats(),
            globalStats: this.getGlobalStats(),
            exportTime: Date.now(),
            version: '2.1.0'
        };
    }

    importData(data) {
        try {
            if (data.gens) {
                world.setDynamicProperty('gens_data', JSON.stringify(data.gens));
            }
            
            if (data.stats) {
                world.setDynamicProperty('gens_stats', JSON.stringify(data.stats));
            }
            
            if (data.globalStats) {
                world.setDynamicProperty('global_stats', JSON.stringify(data.globalStats));
            }
            
            return true;
        } catch {
            return false;
        }
    }

    getDataSize() {
        const gensData = world.getDynamicProperty('gens_data') || '{}';
        const statsData = world.getDynamicProperty('gens_stats') || '{}';
        const globalStatsData = world.getDynamicProperty('global_stats') || '{}';
        
        return {
            gens: gensData.length,
            stats: statsData.length,
            globalStats: globalStatsData.length,
            total: gensData.length + statsData.length + globalStatsData.length
        };
    }

    optimizeData() {
        this.cleanupInvalidGens();
        
        const allStats = this.getAllStats();
        const currentTime = Date.now();
        const oneWeekAgo = currentTime - (7 * 24 * 60 * 60 * 1000);
        
        let optimized = false;
        
        for (const genId in allStats) {
            const stats = allStats[genId];
            
            if (stats.lastActive < oneWeekAgo && stats.generationCount === 0) {
                delete allStats[genId];
                optimized = true;
            }
        }
        
        if (optimized) {
            world.setDynamicProperty('gens_stats', JSON.stringify(allStats));
        }
        
        return optimized;
    }

    resetData() {
        world.setDynamicProperty('gens_data', '{}');
        world.setDynamicProperty('gens_stats', '{}');
        world.setDynamicProperty('global_stats', JSON.stringify({
            totalGensCreated: 0,
            totalItemsGenerated: 0,
            totalValueGenerated: 0
        }));
    }

    validateDataIntegrity() {
        const issues = [];
        
        try {
            const gens = this.getAllGens();
            const stats = this.getAllStats();
            
            for (const genId in gens) {
                const gen = gens[genId];
                
                if (!gen.id || !gen.owner || !gen.location) {
                    issues.push(`Gen ${genId}: Missing required fields`);
                }
                
                if (!gen.item || !gen.rarity || !gen.mode) {
                    issues.push(`Gen ${genId}: Missing configuration`);
                }
                
                if (typeof gen.amount !== 'number' || typeof gen.interval !== 'number') {
                    issues.push(`Gen ${genId}: Invalid numeric values`);
                }
            }
            
            for (const statId in stats) {
                if (!gens[statId]) {
                    issues.push(`Orphaned stats for gen ${statId}`);
                }
            }
            
        } catch (error) {
            issues.push(`Data corruption detected: ${error.message}`);
        }
        
        return issues;
    }

    repairData() {
        const allGens = this.getAllGens();
        const allStats = this.getAllStats();
        let repaired = false;
        
        for (const genId in allGens) {
            const gen = allGens[genId];
            
            if (!gen.id) {
                gen.id = genId;
                repaired = true;
            }
            
            if (!gen.lastGeneration) {
                gen.lastGeneration = Date.now();
                repaired = true;
            }
            
            if (!gen.multiplier) {
                gen.multiplier = 1;
                repaired = true;
            }
            
            if (!gen.speed_level) gen.speed_level = 0;
            if (!gen.amount_level) gen.amount_level = 0;
            if (!gen.efficiency_level) gen.efficiency_level = 0;
            if (!gen.prestige_level) gen.prestige_level = 0;
        }
        
        for (const statId in allStats) {
            if (!allGens[statId]) {
                delete allStats[statId];
                repaired = true;
            }
        }
        
        if (repaired) {
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
            world.setDynamicProperty('gens_stats', JSON.stringify(allStats));
        }
        
        return repaired;
    }
}