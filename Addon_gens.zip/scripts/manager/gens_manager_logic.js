import { world, system } from '@minecraft/server';
import { GensManagerData } from './gens_manager_data.js';

export class GensManager {
    constructor() {
        this.data = new GensManagerData();
        this.cleanupIntervalId = null;
        this.optimizeIntervalId = null;
        this.backupIntervalId = null;
        this.initializeCleanupTasks();
    }

    initializeCleanupTasks() {
        this.cleanupIntervalId = system.runInterval(() => {
            this.data.cleanupInvalidGens();
        }, 300);

        this.optimizeIntervalId = system.runInterval(() => {
            this.data.optimizeData();
        }, 600);

        this.backupIntervalId = system.runInterval(() => {
            this.data.backupData();
        }, 1800);
    }

    createGen(location, config, ownerName) {
        const genId = this.generateGenId();
        
        const genData = {
            id: genId,
            owner: ownerName,
            location: location,
            dimension: 'overworld',
            item: config.item,
            rarity: config.rarity,
            mode: config.mode,
            amount: config.amount,
            interval: config.interval,
            name: config.name || 'Generador',
            lastGeneration: Date.now(),
            multiplier: 1,
            speed_level: 0,
            amount_level: 0,
            efficiency_level: 0,
            prestige_level: 0,
            protection: config.protection || true,
            notifications: config.notifications || false,
            energy: config.useEnergy ? config.energyCost : null,
            maxEnergy: config.useEnergy ? config.energyCost : null,
            createdAt: Date.now(),
            totalGenerated: 0
        };

        this.data.saveGen(genId, genData);
        this.data.incrementGensCreated();
        
        const initialStats = {
            totalItems: 0,
            totalValue: 0,
            generationCount: 0,
            createdAt: Date.now(),
            lastActive: Date.now()
        };
        
        this.data.saveGenStats(genId, initialStats);
        
        return genId;
    }

    getGenAt(location) {
        return this.data.getGenByLocation(location);
    }

    getAllGens() {
        return this.data.getAllGens();
    }

    removeGen(location) {
        const gen = this.data.getGenByLocation(location);
        if (gen) {
            this.data.removeGen(gen.id);
            return true;
        }
        return false;
    }

    updateGenLastGeneration(genId, timestamp) {
        return this.data.updateGenProperty(genId, 'lastGeneration', timestamp);
    }

    upgradeGen(genId, upgradeType, level = 1) {
        const gen = this.data.getGen(genId);
        if (!gen) return false;

        const currentLevel = gen[upgradeType + '_level'] || 0;
        const newLevel = currentLevel + level;
        
        this.data.updateGenProperty(genId, upgradeType + '_level', newLevel);

        switch (upgradeType) {
            case 'speed':
                const newInterval = Math.max(500, gen.interval * Math.pow(0.95, level));
                this.data.updateGenProperty(genId, 'interval', newInterval);
                break;
                
            case 'amount':
                const newAmount = Math.floor(gen.amount * Math.pow(1.2, level));
                this.data.updateGenProperty(genId, 'amount', newAmount);
                break;
                
            case 'efficiency':
                const newMultiplier = (gen.multiplier || 1) * Math.pow(1.15, level);
                this.data.updateGenProperty(genId, 'multiplier', newMultiplier);
                break;
        }

        return true;
    }

    prestigeGen(genId) {
        const gen = this.data.getGen(genId);
        if (!gen) return false;

        const prestigeLevel = (gen.prestige_level || 0) + 1;
        
        this.data.updateGenProperty(genId, 'prestige_level', prestigeLevel);
        this.data.updateGenProperty(genId, 'speed_level', 0);
        this.data.updateGenProperty(genId, 'amount_level', 0);
        this.data.updateGenProperty(genId, 'efficiency_level', 0);
        
        const baseMultiplier = prestigeLevel * 2;
        this.data.updateGenProperty(genId, 'multiplier', baseMultiplier);
        
        const originalInterval = this.getOriginalInterval(gen.rarity);
        const originalAmount = this.getOriginalAmount(gen.rarity);
        
        this.data.updateGenProperty(genId, 'interval', originalInterval);
        this.data.updateGenProperty(genId, 'amount', originalAmount);

        return true;
    }

    getOriginalInterval(rarity) {
        const intervals = {
            'Común': 10000,
            'Poco Común': 8000,
            'Raro': 6000,
            'Épico': 4000,
            'Legendario': 2000,
            'Mítico': 1000
        };
        return intervals[rarity] || 10000;
    }

    getOriginalAmount(rarity) {
        const amounts = {
            'Común': 1,
            'Poco Común': 2,
            'Raro': 3,
            'Épico': 5,
            'Legendario': 8,
            'Mítico': 12
        };
        return amounts[rarity] || 1;
    }

    generateGenId() {
        return 'gen_' + Date.now() + '_' + Math.random().toString(36).substring(2);
    }

    getGenProductionRate(genId) {
        const gen = this.data.getGen(genId);
        if (!gen) return 0;

        const itemsPerSecond = gen.amount / (gen.interval / 1000);
        const multipliedRate = itemsPerSecond * (gen.multiplier || 1);
        
        return Math.round(multipliedRate * 100) / 100;
    }

    getGenEfficiency(genId) {
        const gen = this.data.getGen(genId);
        const stats = this.data.getGenStats(genId);
        
        if (!gen || !stats.createdAt) return 0;

        const timeActive = Date.now() - stats.createdAt;
        const expectedGenerations = Math.floor(timeActive / gen.interval);
        
        if (expectedGenerations === 0) return 100;
        
        const efficiency = (stats.generationCount / expectedGenerations) * 100;
        return Math.min(100, Math.round(efficiency));
    }

    validateGenPlacement(location, player) {
        const nearbyGens = this.getNearbyGens(location, 5);
        
        if (nearbyGens.length >= 10) {
            return {
                valid: false,
                reason: 'Demasiados generadores cercanos (máximo 10 en 5 bloques)'
            };
        }

        const playerGens = Object.values(this.data.getPlayerGens(player.name));
        
        if (playerGens.length >= 50 && !player.hasTag('VIP')) {
            return {
                valid: false,
                reason: 'Límite de generadores alcanzado (50). Necesitas VIP para más.'
            };
        }

        if (playerGens.length >= 200 && player.hasTag('VIP')) {
            return {
                valid: false,
                reason: 'Límite VIP de generadores alcanzado (200)'
            };
        }

        return { valid: true };
    }

    getNearbyGens(location, radius) {
        const allGens = this.data.getAllGens();
        const nearbyGens = [];

        for (const genId in allGens) {
            const gen = allGens[genId];
            const distance = this.calculateDistance(location, gen.location);
            
            if (distance <= radius) {
                nearbyGens.push(gen);
            }
        }

        return nearbyGens;
    }

    calculateDistance(pos1, pos2) {
        const dx = pos1.x - pos2.x;
        const dy = pos1.y - pos2.y;
        const dz = pos1.z - pos2.z;
        
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    transferGenOwnership(genId, newOwner) {
        const gen = this.data.getGen(genId);
        if (!gen) return false;

        this.data.updateGenProperty(genId, 'owner', newOwner);
        return true;
    }

    pauseGen(genId) {
        return this.data.updateGenProperty(genId, 'paused', true);
    }

    resumeGen(genId) {
        return this.data.updateGenProperty(genId, 'paused', false);
    }

    isGenPaused(genId) {
        const gen = this.data.getGen(genId);
        return gen ? gen.paused || false : true;
    }

    getGenUptime(genId) {
        const gen = this.data.getGen(genId);
        const stats = this.data.getGenStats(genId);
        
        if (!gen || !stats.createdAt) return 0;

        const totalTime = Date.now() - stats.createdAt;
        const pausedTime = gen.totalPausedTime || 0;
        
        return Math.max(0, totalTime - pausedTime);
    }

    toggleGenNotifications(genId) {
        const gen = this.data.getGen(genId);
        if (!gen) return false;

        const newState = !gen.notifications;
        return this.data.updateGenProperty(genId, 'notifications', newState);
    }

    bulkUpgrade(genIds, upgradeType, levels = 1) {
        const results = {
            success: 0,
            failed: 0,
            errors: []
        };

        genIds.forEach(genId => {
            try {
                if (this.upgradeGen(genId, upgradeType, levels)) {
                    results.success++;
                } else {
                    results.failed++;
                    results.errors.push(`Failed to upgrade gen ${genId}`);
                }
            } catch (error) {
                results.failed++;
                results.errors.push(`Error upgrading gen ${genId}: ${error.message}`);
            }
        });

        return results;
    }

    getGenHistory(genId, days = 7) {
        const gen = this.data.getGen(genId);
        if (!gen) return null;

        const history = gen.history || [];
        const cutoffDate = Date.now() - (days * 24 * 60 * 60 * 1000);
        
        return history.filter(entry => entry.timestamp >= cutoffDate);
    }

    recordGenActivity(genId, activityType, data = {}) {
        const gen = this.data.getGen(genId);
        if (!gen) return false;

        const activity = {
            timestamp: Date.now(),
            type: activityType,
            data: data
        };

        const history = gen.history || [];
        history.push(activity);

        if (history.length > 1000) {
            history.splice(0, history.length - 1000);
        }

        return this.data.updateGenProperty(genId, 'history', history);
    }
}