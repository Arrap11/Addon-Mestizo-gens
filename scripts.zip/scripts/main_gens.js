import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { EconomyCore } from './economy/economy_core.js';
import { GensManager } from './manager/gens_manager_logic.js';
import { GensTracker } from './tracker/gens_tracker_core.js';
import { FormsGens } from './forms/forms_gens.js';

let economy, manager, tracker, forms;
let systemInitialized = false;

class GensSystem {
    constructor() {
        this.initialize();
    }

    initialize() {
        system.runInterval(() => {
            if (systemInitialized) {
                this.processAllGens();
                this.convertItemsToMoney();
            }
        }, 20);
    }

    processAllGens() {
        try {
            const allGens = manager.getAllGens();
            
            for (const genId in allGens) {
                const gen = allGens[genId];
                this.processGen(gen);
            }
        } catch (error) {
            console.error('[GENS] Error processing gens:', error);
        }
    }

    processGen(gen) {
        if (!gen || !gen.location) return;
        
        const currentTime = Date.now();
        
        if (currentTime - gen.lastGeneration >= gen.interval) {
            try {
                const dimension = world.getDimension(gen.dimension || 'overworld');
                const location = gen.location;
                const block = dimension.getBlock(location);
                
                if (!block || !this.isValidGeneratorBlock(block.typeId)) {
                    console.log(`[GENS] Invalid block at ${location.x},${location.y},${location.z}: ${block?.typeId}`);
                    return;
                }

                console.log(`[GENS] Processing generator ${gen.id} at ${location.x},${location.y},${location.z}`);

                if (gen.mode === 'spawn') {
                    this.spawnItems(dimension, location, gen);
                } else if (gen.mode === 'drop') {
                    this.dropItems(dimension, location, gen);
                }

                manager.updateGenLastGeneration(gen.id, currentTime);
                tracker.recordGeneration(gen.id, gen.amount);
                
                console.log(`[GENS] Generated ${gen.amount} ${gen.item} from generator ${gen.id}`);
                
            } catch (error) {
                console.error(`[GENS] Error processing generator ${gen.id}:`, error);
            }
        }
    }

    isValidGeneratorBlock(blockType) {
        const validBlocks = [
            'minecraft:spawner',
            'minecraft:coal_ore',
            'minecraft:iron_ore',
            'minecraft:gold_ore',
            'minecraft:diamond_ore',
            'minecraft:emerald_ore',
            'minecraft:ancient_debris',
            'minecraft:stone',
            'minecraft:oak_log',
            'minecraft:redstone_ore'
        ];
        return validBlocks.includes(blockType);
    }

    hasContainer(block) {
        if (!block) return false;
        
        const containerTypes = [
            'minecraft:chest',
            'minecraft:trapped_chest',
            'minecraft:hopper',
            'minecraft:shulker_box',
            'minecraft:barrel',
            'minecraft:dispenser',
            'minecraft:dropper'
        ];
        
        return containerTypes.includes(block.typeId);
    }

    spawnItems(dimension, location, gen) {
        try {
            const containerLoc = {
                x: location.x,
                y: location.y - 1,
                z: location.z
            };
            
            const containerBlock = dimension.getBlock(containerLoc);
            
            if (!this.hasContainer(containerBlock)) {
                console.log(`[GENS] No container found below generator at ${containerLoc.x},${containerLoc.y},${containerLoc.z}`);
                return;
            }

            const inventory = containerBlock.getComponent('inventory');
            if (!inventory || !inventory.container) {
                console.log(`[GENS] Container has no inventory component`);
                return;
            }

            const container = inventory.container;
            const finalAmount = Math.floor(gen.amount * (gen.multiplier || 1));
            
            for (let itemsLeft = finalAmount; itemsLeft > 0;) {
                const stackSize = Math.min(itemsLeft, 64);
                const item = new ItemStack(gen.item, stackSize);
                item.setLore([
                    '§6[GENERADOR]',
                    `§7Propietario: ${gen.owner}`,
                    `§7Valor: §a${economy.config.getItemValue(gen.item)} c/u`
                ]);
                
                let added = false;
                
                for (let i = 0; i < container.size; i++) {
                    const slot = container.getItem(i);
                    
                    if (!slot) {
                        container.setItem(i, item);
                        itemsLeft -= stackSize;
                        added = true;
                        break;
                    } else if (slot.typeId === gen.item && this.isGeneratorItem(slot)) {
                        const canAdd = Math.min(stackSize, slot.maxAmount - slot.amount);
                        if (canAdd > 0) {
                            slot.amount += canAdd;
                            container.setItem(i, slot);
                            itemsLeft -= canAdd;
                            
                            if (canAdd < stackSize) {
                                const remaining = new ItemStack(gen.item, stackSize - canAdd);
                                remaining.setLore(item.getLore());
                                
                                for (let j = i + 1; j < container.size; j++) {
                                    const nextSlot = container.getItem(j);
                                    if (!nextSlot) {
                                        container.setItem(j, remaining);
                                        itemsLeft -= (stackSize - canAdd);
                                        break;
                                    }
                                }
                            }
                            added = true;
                            break;
                        }
                    }
                }
                
                if (!added) {
                    console.log(`[GENS] Container full, dropping remaining items`);
                    this.dropItems(dimension, location, {...gen, amount: Math.ceil(itemsLeft / (gen.multiplier || 1))});
                    break;
                }
            }
            
            console.log(`[GENS] Added ${finalAmount} ${gen.item} to container`);
            
        } catch (error) {
            console.error(`[GENS] Error spawning items:`, error);
        }
    }

    dropItems(dimension, location, gen) {
        try {
            const dropLoc = {
                x: location.x + 0.5,
                y: location.y + 1.2,
                z: location.z + 0.5
            };
            
            const finalAmount = Math.floor(gen.amount * (gen.multiplier || 1));
            
            for (let itemsLeft = finalAmount; itemsLeft > 0;) {
                const stackSize = Math.min(itemsLeft, 64);
                const item = new ItemStack(gen.item, stackSize);
                item.setLore([
                    '§6[GENERADOR]',
                    `§7Propietario: ${gen.owner}`,
                    `§7Valor: §a${economy.config.getItemValue(gen.item)} c/u`
                ]);
                
                dimension.spawnItem(item, dropLoc);
                itemsLeft -= stackSize;
                
                console.log(`[GENS] Dropped ${stackSize} ${gen.item} at ${dropLoc.x},${dropLoc.y},${dropLoc.z}`);
            }
            
        } catch (error) {
            console.error(`[GENS] Error dropping items:`, error);
        }
    }

    convertItemsToMoney() {
        try {
            const players = world.getAllPlayers();
            
            players.forEach(player => {
                const inventory = player.getComponent('inventory');
                if (!inventory || !inventory.container) return;
                
                const container = inventory.container;
                let totalValue = 0;
                let itemsConverted = 0;
                
                for (let i = 0; i < container.size; i++) {
                    const item = container.getItem(i);
                    
                    if (item && this.isGeneratorItem(item)) {
                        const itemValue = economy.config.getItemValue(item.typeId);
                        const value = itemValue * item.amount;
                        
                        totalValue += value;
                        itemsConverted += item.amount;
                        
                        container.setItem(i, undefined);
                    }
                }
                
                if (totalValue > 0) {
                    economy.addMoney(player, totalValue);
                    player.sendMessage(`§a+${economy.formatMoney(totalValue)} §7(${itemsConverted} §aitems convertidos)`);
                    tracker.recordEconomyTransaction(player.name, 'earn', totalValue, 'item_conversion');
                }
            });
        } catch (error) {
            console.error('[GENS] Error converting items:', error);
        }
    }

    isGeneratorItem(item) {
        if (!item || !item.getLore) return false;
        
        try {
            const lore = item.getLore();
            return lore.some(line => line.includes('[GENERADOR]'));
        } catch {
            return false;
        }
    }

    handleBlockBreak(event) {
        const { player, block } = event;
        
        try {
            const genData = manager.getGenAt(block.location);
            
            if (genData) {
                if (player.name !== genData.owner && !player.hasTag('Admin')) {
                    event.cancel = true;
                    player.sendMessage('§cEste generador no es tuyo');
                    return;
                }
                
                manager.removeGen(block.location);
                player.sendMessage('§cGenerador eliminado');
                console.log(`[GENS] Generator ${genData.id} removed by ${player.name}`);
            }
        } catch (error) {
            console.error('[GENS] Error handling block break:', error);
        }
    }

    handleBlockPlace(event) {
        const { player, block } = event;
        
        try {
            if (this.isValidGeneratorBlock(block.typeId)) {
                const genConfig = player.getDynamicProperty('temp_gen_config');
                
                if (genConfig) {
                    const config = JSON.parse(genConfig);
                    
                    const validation = manager.validateGenPlacement(block.location, player);
                    if (!validation.valid) {
                        player.sendMessage(`§c${validation.reason}`);
                        return;
                    }
                    
                    const genId = manager.createGen(block.location, config, player.name);
                    player.setDynamicProperty('temp_gen_config', undefined);
                    
                    player.sendMessage('§aGenerador activado correctamente');
                    player.sendMessage(`§7ID: ${genId}`);
                    player.sendMessage(`§7Modo: ${config.mode === 'spawn' ? 'Requiere cofre abajo' : 'Suelta items al aire'}`);
                    
                    console.log(`[GENS] Generator ${genId} created by ${player.name} at ${block.location.x},${block.location.y},${block.location.z}`);
                }
            }
        } catch (error) {
            console.error('[GENS] Error handling block place:', error);
            player.sendMessage('§cError al activar el generador');
        }
    }
}

system.run(() => {
    system.runTimeout(() => {
        try {
            economy = new EconomyCore();
            manager = new GensManager();
            tracker = new GensTracker();
            forms = new FormsGens();
            
            systemInitialized = true;
            gensSystem = new GensSystem();
            
            console.log('§a[GENS] Sistema iniciado correctamente');
        } catch (error) {
            console.error('§c[GENS] Error al inicializar:', error);
        }
    }, 100);
});

world.beforeEvents.chatSend.subscribe((event) => {
    const { sender: player, message } = event;
    
    if (message === '!uigens') {
        event.cancel = true;
        
        system.runTimeout(() => {
            if (!player.hasTag('Admin')) {
                player.sendMessage('§cNecesitas permisos de administrador');
                return;
            }
            
            if (!systemInitialized) {
                player.sendMessage('§cEl sistema aun se esta inicializando...');
                return;
            }
            
            forms.showMainMenu(player);
        }, 30);
    }

    if (message === '!sellall') {
        event.cancel = true;
        
        system.runTimeout(() => {
            if (!systemInitialized) return;
            
            const inventory = player.getComponent('inventory');
            if (!inventory || !inventory.container) return;
            
            const container = inventory.container;
            let totalValue = 0;
            let itemsConverted = 0;
            
            for (let i = 0; i < container.size; i++) {
                const item = container.getItem(i);
                
                if (item && gensSystem.isGeneratorItem(item)) {
                    const itemValue = economy.config.getItemValue(item.typeId);
                    const value = itemValue * item.amount;
                    
                    totalValue += value;
                    itemsConverted += item.amount;
                    
                    container.setItem(i, undefined);
                }
            }
            
            if (totalValue > 0) {
                economy.addMoney(player, totalValue);
                player.sendMessage(`§aVendido! +${economy.formatMoney(totalValue)} §7(${itemsConverted} items)`);
            } else {
                player.sendMessage('§7No tienes items de generador para vender');
            }
        }, 20);
    }

    if (message === '!debuggens') {
        event.cancel = true;
        
        if (!player.hasTag('Admin')) return;
        
        system.runTimeout(() => {
            const allGens = manager.getAllGens();
            const genCount = Object.keys(allGens).length;
            
            player.sendMessage(`§7=== DEBUG GENS ===`);
            player.sendMessage(`§7Total generadores: §a${genCount}`);
            
            if (genCount > 0) {
                Object.values(allGens).slice(0, 5).forEach(gen => {
                    const timeSince = Date.now() - gen.lastGeneration;
                    const timeUntil = Math.max(0, gen.interval - timeSince);
                    player.sendMessage(`§7${gen.id}: if${gen.item} §7(${Math.ceil(timeUntil/1000)}s)`);
                });
            }
        }, 20);
    }
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    if (systemInitialized && gensSystem) {
        gensSystem.handleBlockBreak(event);
    }
});

world.beforeEvents.playerPlaceBlock.subscribe((event) => {
    if (systemInitialized && gensSystem) {
        gensSystem.handleBlockPlace(event);
    }
});

let gensSystem;