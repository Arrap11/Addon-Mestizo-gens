export class EconomyConfig {
    constructor() {
        this.upgradeCosts = {
            speed: 1000,
            amount: 1500,
            efficiency: 2000
        };
        
        this.rarityMultipliers = {
            'Común': 1,
            'Poco Común': 1.5,
            'Raro': 2.5,
            'Épico': 4,
            'Legendario': 6,
            'Mítico': 10
        };
        
        this.itemValues = {
            'minecraft:coal': 10,
            'minecraft:iron_ingot': 50,
            'minecraft:gold_ingot': 100,
            'minecraft:diamond': 500,
            'minecraft:emerald': 750,
            'minecraft:netherite_ingot': 2000,
            'minecraft:cobblestone': 1,
            'minecraft:stone': 2,
            'minecraft:oak_log': 5,
            'minecraft:redstone': 25
        };
    }

    getUpgradeCost(upgradeType) {
        return this.upgradeCosts[upgradeType] || 1000;
    }

    getRarityMultiplier(rarity) {
        return this.rarityMultipliers[rarity] || 1;
    }

    getItemValue(itemType) {
        return this.itemValues[itemType] || 1;
    }

    getRarities() {
        return Object.keys(this.rarityMultipliers);
    }

    getAvailableItems() {
        return Object.keys(this.itemValues);
    }

    calculateGenCost(item, rarity, baseInterval, baseAmount) {
        const itemValue = this.getItemValue(item);
        const rarityMult = this.getRarityMultiplier(rarity);
        const speedFactor = Math.max(1, 10000 / baseInterval);
        const amountFactor = baseAmount;
        
        return Math.floor(itemValue * rarityMult * speedFactor * amountFactor * 10);
    }

    getIntervalFromRarity(rarity) {
        const intervals = {
            'Común': 10000,
            'Poco Común': 8000,
            'Raro': 6000,
            'Épico': 4000,
            'Legendario': 2000,
            'Mítico': 1000
        };
        return intervals[rarity] || 10000;
    }

    getBaseAmountFromRarity(rarity) {
        const amounts = {
            'Común': 1,
            'Poco Común': 2,
            'Raro': 3,
            'Épico': 5,
            'Legendario': 8,
            'Mítico': 12
        };
        return amounts[rarity] || 1;
    }

    validateGenConfig(config) {
        const requiredFields = ['item', 'rarity', 'mode'];
        
        for (const field of requiredFields) {
            if (!config[field]) {
                return { valid: false, error: `Campo requerido: ${field}` };
            }
        }

        if (!this.getAvailableItems().includes(config.item)) {
            return { valid: false, error: 'Ítem no válido' };
        }

        if (!this.getRarities().includes(config.rarity)) {
            return { valid: false, error: 'Rareza no válida' };
        }

        if (!['drop', 'spawn'].includes(config.mode)) {
            return { valid: false, error: 'Modo no válido' };
        }

        return { valid: true };
    }
}