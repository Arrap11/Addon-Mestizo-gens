import { world } from '@minecraft/server';
import { EconomyCore } from '../economy/economy_core.js';

export class FormsUILogic {
    constructor() {
        this.economy = new EconomyCore();
    }

    getPlayerGens(playerName) {
        const allGens = this.getAllGens();
        return Object.values(allGens).filter(gen => gen.owner === playerName);
    }

    getAllGens() {
        return JSON.parse(world.getDynamicProperty('gens_data') || '{}');
    }

    getGenStatus(gen) {
        const now = Date.now();
        const timeSinceLastGen = now - gen.lastGeneration;
        const timeUntilNext = Math.max(0, gen.interval - timeSinceLastGen);
        
        if (timeUntilNext === 0) {
            return `§aListo para generar`;
        }
        
        const secondsLeft = Math.ceil(timeUntilNext / 1000);
        return `§7${secondsLeft}s restantes`;
    }

    getGenDetails(gen) {
        const speedLevel = gen.speed_level || 0;
        const amountLevel = gen.amount_level || 0;
        const efficiencyLevel = gen.efficiency_level || 0;
        const prestigeLevel = gen.prestige_level || 0;

        const itemValue = this.economy.config.getItemValue(gen.item);
        const finalAmount = Math.floor(gen.amount * (gen.multiplier || 1));
        const valuePerGen = itemValue * finalAmount;
        const valuePerHour = Math.floor((valuePerGen * 3600000) / gen.interval);

        return `§7=== Detalles del Generador ===

§7Ítem: §f${gen.item}
§7Rareza: §${this.getRarityColor(gen.rarity)}${gen.rarity}
§7Modo: §f${gen.mode === 'spawn' ? 'Spawn (requiere cofre)' : 'Drop (suelta al aire)'}

§7=== Producción ===
§7Cantidad por gen: §a${finalAmount} items
§7Valor por gen: §6${this.economy.formatMoney(valuePerGen)}
§7Valor por hora: §6${this.economy.formatMoney(valuePerHour)}
§7Velocidad: §b${(gen.interval / 1000).toFixed(1)}s
§7Multiplicador: §e${(gen.multiplier || 1).toFixed(1)}x

§7=== Niveles de Mejora ===
§2Velocidad: §fNivel ${speedLevel}
§3Cantidad: §fNivel ${amountLevel}  
§5Eficiencia: §fNivel ${efficiencyLevel}
§6Prestigio: §fNivel ${prestigeLevel}

§7=== Costos de Mejora ===
§2Velocidad: §6${this.economy.formatMoney(this.economy.getUpgradeCost(speedLevel, 'speed'))}
§3Cantidad: §6${this.economy.formatMoney(this.economy.getUpgradeCost(amountLevel, 'amount'))}
§5Eficiencia: §6${this.economy.formatMoney(this.economy.getUpgradeCost(efficiencyLevel, 'efficiency'))}

§8Tip: Los ítems se convierten automáticamente en dinero`;
    }

    upgradeGen(player, genId, upgradeType) {
        const success = this.economy.processUpgrade(player, genId, upgradeType);
        
        if (success) {
            const upgradeNames = {
                'speed': 'Velocidad',
                'amount': 'Cantidad', 
                'efficiency': 'Eficiencia'
            };
            player.sendMessage(`§aMejora de ${upgradeNames[upgradeType]} aplicada exitosamente`);
            return true;
        } else {
            player.sendMessage('§cNo tienes suficiente dinero para esta mejora');
            return false;
        }
    }

    getPrestigeCost(gen) {
        return this.economy.formatMoney(this.economy.calculatePrestigeCost(gen));
    }

    prestigeGen(player, genId) {
        return this.economy.prestigeGen(player, genId);
    }

    deleteGen(genId) {
        const allGens = this.getAllGens();
        delete allGens[genId];
        world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        
        const stats = JSON.parse(world.getDynamicProperty('gens_stats') || '{}');
        delete stats[genId];
        world.setDynamicProperty('gens_stats', JSON.stringify(stats));
    }

    getGlobalStats() {
        const allGens = Object.values(this.getAllGens());
        const allStats = JSON.parse(world.getDynamicProperty('gens_stats') || '{}');
        
        const totalGens = allGens.length;
        const activeGens = allGens.filter(gen => Date.now() - gen.lastGeneration < gen.interval * 2).length;
        
        let totalItemsGenerated = 0;
        let totalValueGenerated = 0;
        
        Object.values(allStats).forEach(stat => {
            totalItemsGenerated += stat.totalItems || 0;
            totalValueGenerated += stat.totalValue || 0;
        });

        const gensByRarity = {};
        const gensByMode = { spawn: 0, drop: 0 };
        
        allGens.forEach(gen => {
            gensByRarity[gen.rarity] = (gensByRarity[gen.rarity] || 0) + 1;
            gensByMode[gen.mode] = (gensByMode[gen.mode] || 0) + 1;
        });

        const topProducers = allGens
            .map(gen => {
                const stats = allStats[gen.id] || {};
                const itemValue = this.economy.config.getItemValue(gen.item);
                const estimatedValue = (stats.totalItems || 0) * itemValue;
                return {
                    name: gen.name,
                    owner: gen.owner,
                    production: stats.totalItems || 0,
                    value: estimatedValue
                };
            })
            .sort((a, b) => b.value - a.value)
            .slice(0, 5);

        let totalPotentialIncome = 0;
        allGens.forEach(gen => {
            const itemValue = this.economy.config.getItemValue(gen.item);
            const finalAmount = Math.floor(gen.amount * (gen.multiplier || 1));
            const valuePerGen = itemValue * finalAmount;
            const valuePerHour = (valuePerGen * 3600000) / gen.interval;
            totalPotentialIncome += valuePerHour;
        });

        let statsText = `§7=== Estadísticas Globales ===

§7Generadores Totales: §a${totalGens}
§7Generadores Activos: §b${activeGens}
§7Ítems Generados: §e${this.economy.formatMoney(totalItemsGenerated)}
§7Valor Total Estimado: §6${this.economy.formatMoney(totalValueGenerated)}
§7Potencial por Hora: §6${this.economy.formatMoney(Math.floor(totalPotentialIncome))}

§7=== Por Rareza ===`;

        Object.entries(gensByRarity).forEach(([rarity, count]) => {
            statsText += `\n§${this.getRarityColor(rarity)}${rarity}: §f${count}`;
        });

        statsText += `\n\n§7=== Por Modo ===
§2Spawn Mode: §f${gensByMode.spawn}
§3Drop Mode: §f${gensByMode.drop}`;

        statsText += '\n\n§7=== Top Productores (Valor) ===';
        topProducers.forEach((producer, index) => {
            statsText += `\n§${index + 1}. §f${producer.name} §7(${producer.owner}) - §6${this.economy.formatMoney(producer.value)}`;
        });

        statsText += '\n\n§8Los ítems se convierten automáticamente en dinero';

        return statsText;
    }

    updateGlobalMultipliers(values) {
        const [speedMult, amountMult, expMult, active] = values;
        
        const multipliers = {
            speed: speedMult,
            amount: amountMult,
            experience: expMult,
            active: active
        };
        
        world.setDynamicProperty('global_multipliers', JSON.stringify(multipliers));
        
        if (active) {
            world.getAllPlayers().forEach(player => {
                player.sendMessage(`§aMultiplicadores globales activados: §bVelocidad x${speedMult} §aAmount x${amountMult} §eExp x${expMult}`);
            });
        }
    }

    activateEvent(eventType) {
        const events = [
            { type: 'double_production', duration: 3600000, name: '2x Producción de Ítems', multiplier: 2 },
            { type: 'speed_boost', duration: 1800000, name: 'Velocidad +100%', speedBoost: 0.5 },
            { type: 'bonus_rewards', duration: 7200000, name: 'Bonificación +50%', bonus: 1.5 }
        ];

        const event = events[eventType];
        if (event) {
            const eventData = {
                ...event,
                startTime: Date.now(),
                endTime: Date.now() + event.duration
            };
            
            world.setDynamicProperty('active_event', JSON.stringify(eventData));
            
            world.getAllPlayers().forEach(player => {
                player.sendMessage(`§6§l[EVENTO ACTIVADO] §e${event.name}`);
                player.sendMessage(`§7Duración: §b${Math.floor(event.duration / 60000)} minutos`);
            });
            
            this.applyEventToAllGens(event);
        }
    }

    applyEventToAllGens(event) {
        const allGens = this.getAllGens();
        let modified = false;
        
        Object.keys(allGens).forEach(genId => {
            const gen = allGens[genId];
            
            switch (event.type) {
                case 'double_production':
                    gen.multiplier = (gen.multiplier || 1) * event.multiplier;
                    modified = true;
                    break;
                case 'speed_boost':
                    gen.interval = Math.max(1000, Math.floor(gen.interval * event.speedBoost));
                    modified = true;
                    break;
                case 'bonus_rewards':
                    gen.multiplier = (gen.multiplier || 1) * event.bonus;
                    modified = true;
                    break;
            }
        });
        
        if (modified) {
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        }
    }

    updateEnergySystem(values) {
        const [enabled, maxEnergy, regen, consumption] = values;
        
        const energyConfig = {
            enabled: enabled,
            maxEnergy: Math.floor(maxEnergy),
            regeneration: regen,
            consumption: Math.floor(consumption)
        };
        
        world.setDynamicProperty('energy_system', JSON.stringify(energyConfig));
        
        if (enabled) {
            const allGens = this.getAllGens();
            Object.keys(allGens).forEach(genId => {
                allGens[genId].energy = maxEnergy;
                allGens[genId].maxEnergy = maxEnergy;
            });
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
            
            world.getAllPlayers().forEach(player => {
                player.sendMessage('§aSistema de energía activado para todos los generadores');
            });
        }
    }

    resetAllStats() {
        world.setDynamicProperty('gens_stats', '{}');
        world.setDynamicProperty('global_stats', '{}');
        world.setDynamicProperty('active_event', '{}');
        world.setDynamicProperty('global_multipliers', '{}');
        world.setDynamicProperty('energy_system', '{}');
        
        const allGens = this.getAllGens();
        Object.keys(allGens).forEach(genId => {
            allGens[genId].totalGenerated = 0;
            allGens[genId].lastGeneration = Date.now();
            allGens[genId].multiplier = 1;
        });
        world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        
        world.getAllPlayers().forEach(player => {
            player.sendMessage('§aEstadísticas y configuraciones reseteadas completamente');
        });
    }

    getRarityColor(rarity) {
        const colors = {
            'Común': 'f',
            'Poco Común': 'a', 
            'Raro': '9',
            'Épico': '5',
            'Legendario': '6',
            'Mítico': 'c'
        };
        return colors[rarity] || 'f';
    }

    getActiveEvent() {
        const eventData = world.getDynamicProperty('active_event');
        if (!eventData) return null;
        
        try {
            const event = JSON.parse(eventData);
            if (Date.now() > event.endTime) {
                world.setDynamicProperty('active_event', '{}');
                this.deactivateEventEffects();
                return null;
            }
            return event;
        } catch {
            return null;
        }
    }

    deactivateEventEffects() {
        const allGens = this.getAllGens();
        let modified = false;
        
        Object.keys(allGens).forEach(genId => {
            const gen = allGens[genId];
            
            if ((gen.multiplier || 1) > 1) {
                gen.multiplier = Math.max(1, (gen.multiplier || 1) / 2);
                modified = true;
            }
        });
        
        if (modified) {
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        }
        
        world.getAllPlayers().forEach(player => {
            player.sendMessage('§7Evento especial terminado - Efectos removidos');
        });
    }

    getEnergySystem() {
        const energyData = world.getDynamicProperty('energy_system');
        if (!energyData) return { enabled: false };
        
        try {
            return JSON.parse(energyData);
        } catch {
            return { enabled: false };
        }
    }

    canGenerate(gen) {
        const energySystem = this.getEnergySystem();
        
        if (!energySystem.enabled) return true;
        
        const currentEnergy = gen.energy || energySystem.maxEnergy;
        return currentEnergy >= energySystem.consumption;
    }

    consumeEnergy(genId) {
        const energySystem = this.getEnergySystem();
        if (!energySystem.enabled) return;

        const allGens = this.getAllGens();
        const gen = allGens[genId];
        
        if (gen) {
            gen.energy = Math.max(0, (gen.energy || energySystem.maxEnergy) - energySystem.consumption);
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        }
    }

    regenerateEnergy() {
        const energySystem = this.getEnergySystem();
        if (!energySystem.enabled) return;

        const allGens = this.getAllGens();
        let modified = false;

        Object.keys(allGens).forEach(genId => {
            const gen = allGens[genId];
            const currentEnergy = gen.energy || 0;
            
            if (currentEnergy < energySystem.maxEnergy) {
                gen.energy = Math.min(energySystem.maxEnergy, currentEnergy + energySystem.regeneration);
                modified = true;
            }
        });

        if (modified) {
            world.setDynamicProperty('gens_data', JSON.stringify(allGens));
        }
    }
}