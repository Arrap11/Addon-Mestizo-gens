import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { FormsCreator } from './forms_creator.js';
import { FormsUILogic } from './forms_ui_logic.js';

export class FormsGens {
    constructor() {
        this.creator = new FormsCreator();
        this.uiLogic = new FormsUILogic();
    }

    async showMainMenu(player) {
        const form = new ActionFormData()
            .title('§6§lSistema de Generadores')
            .body('§7Selecciona una opción:')
            .button('§2Crear Generador', 'textures/items/emerald')
            .button('§3Gestionar Generadores', 'textures/blocks/command_block')
            .button('§5Estadísticas Globales', 'textures/items/book_writable')
            .button('§4Configuración Avanzada', 'textures/items/redstone')
            .button('§8Cerrar', 'textures/items/barrier');

        try {
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            switch (response.selection) {
                case 0:
                    await this.creator.showCreateGenForm(player);
                    break;
                case 1:
                    await this.showManageGens(player);
                    break;
                case 2:
                    await this.showGlobalStats(player);
                    break;
                case 3:
                    await this.showAdvancedConfig(player);
                    break;
            }
        } catch (error) {
            console.error("Error en showMainMenu:", error);
            player.sendMessage('§cError al mostrar el menú principal');
        }
    }

    async showManageGens(player) {
        try {
            const playerGens = this.uiLogic.getPlayerGens(player.name);
            if (playerGens.length === 0) {
                const form = new MessageFormData()
                    .title('§6Gestionar Generadores')
                    .body('§7No tienes generadores creados')
                    .button1('§2Crear Generador')
                    .button2('§8Volver');
                const response = await form.show(player);
                if (!response.canceled && response.selection === 0) {
                    await this.creator.showCreateGenForm(player);
                } else {
                    await this.showMainMenu(player);
                }
                return;
            }
            const form = new ActionFormData()
                .title('§6Gestionar Generadores')
                .body('§7Selecciona un generador:');
            playerGens.forEach(gen => {
                const status = this.uiLogic.getGenStatus(gen);
                form.button(`§e${gen.item}\n§7${status}`, 'textures/blocks/spawner');
            });
            form.button('§8Volver', 'textures/items/barrier');
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            if (response.selection === playerGens.length) {
                await this.showMainMenu(player);
                return;
            }
            const selectedGen = playerGens[response.selection];
            await this.showGenDetails(player, selectedGen);
        } catch (error) {
            console.error("Error en showManageGens:", error);
            player.sendMessage('§cError al mostrar generadores');
        }
    }

    async showGenDetails(player, gen) {
        try {
            const details = this.uiLogic.getGenDetails(gen);
            const form = new ActionFormData()
                .title(`§6Generador: ${gen.item}`)
                .body(details)
                .button('§2Mejorar Velocidad', 'textures/items/clock')
                .button('§3Mejorar Cantidad', 'textures/items/diamond')
                .button('§5Mejorar Eficiencia', 'textures/items/nether_star')
                .button('§6Prestigio', 'textures/items/totem')
                .button('§4Eliminar', 'textures/items/barrier')
                .button('§8Volver', 'textures/items/arrow');
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            switch (response.selection) {
                case 0:
                    this.uiLogic.upgradeGen(player, gen.id, 'speed');
                    await this.showGenDetails(player, gen);
                    break;
                case 1:
                    this.uiLogic.upgradeGen(player, gen.id, 'amount');
                    await this.showGenDetails(player, gen);
                    break;
                case 2:
                    this.uiLogic.upgradeGen(player, gen.id, 'efficiency');
                    await this.showGenDetails(player, gen);
                    break;
                case 3:
                    await this.showPrestigeConfirm(player, gen);
                    break;
                case 4:
                    await this.showDeleteConfirm(player, gen);
                    break;
                case 5:
                    await this.showManageGens(player);
                    break;
            }
        } catch (error) {
            console.error("Error en showGenDetails:", error);
            player.sendMessage('§cError al mostrar detalles del generador');
        }
    }

    async showPrestigeConfirm(player, gen) {
        try {
            const cost = this.uiLogic.getPrestigeCost(gen);
            const form = new MessageFormData()
                .title('§6Confirmar Prestigio')
                .body(`§7¿Estás seguro de hacer prestigio a este generador?\n\n§cCosto: §e${cost} monedas\n\n§7Esto reiniciará todas las mejoras pero aumentará el multiplicador base.`)
                .button1('§2Confirmar')
                .button2('§4Cancelar');
            const response = await form.show(player);
            if (!response.canceled && response.selection === 0) {
                if (this.uiLogic.prestigeGen(player, gen.id)) {
                    player.sendMessage('§aGenerador prestigiado exitosamente');
                } else {
                    player.sendMessage('§cNo tienes suficiente dinero');
                }
            }
            await this.showGenDetails(player, gen);
        } catch (error) {
            console.error("Error en showPrestigeConfirm:", error);
            player.sendMessage('§cError al mostrar confirmación de prestigio');
        }
    }

    async showDeleteConfirm(player, gen) {
        try {
            const form = new MessageFormData()
                .title('§4Confirmar Eliminación')
                .body('§7¿Estás seguro de eliminar este generador?\n\n§cEsta acción no se puede deshacer.')
                .button1('§4Eliminar')
                .button2('§2Cancelar');
            const response = await form.show(player);
            if (!response.canceled && response.selection === 0) {
                this.uiLogic.deleteGen(gen.id);
                player.sendMessage('§aGenerador eliminado exitosamente');
                await this.showManageGens(player);
            } else {
                await this.showGenDetails(player, gen);
            }
        } catch (error) {
            console.error("Error en showDeleteConfirm:", error);
            player.sendMessage('§cError al mostrar confirmación de eliminación');
        }
    }

    async showGlobalStats(player) {
        try {
            const stats = this.uiLogic.getGlobalStats();
            const form = new MessageFormData()
                .title('§6Estadísticas Globales')
                .body(stats)
                .button1('§2Actualizar')
                .button2('§8Volver');
            const response = await form.show(player);
            if (!response.canceled) {
                if (response.selection === 0) {
                    await this.showGlobalStats(player);
                } else {
                    await this.showMainMenu(player);
                }
            }
        } catch (error) {
            console.error("Error en showGlobalStats:", error);
            player.sendMessage('§cError al mostrar estadísticas globales');
        }
    }

    async showAdvancedConfig(player) {
        try {
            const form = new ActionFormData()
                .title('§6Configuración Avanzada')
                .body('§7Opciones de administrador:')
                .button('§2Multiplicadores Globales', 'textures/items/nether_star')
                .button('§3Eventos Especiales', 'textures/items/firework_star')
                .button('§5Sistema de Energía', 'textures/items/redstone')
                .button('§4Resetear Estadísticas', 'textures/items/barrier')
                .button('§8Volver', 'textures/items/arrow');
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            switch (response.selection) {
                case 0:
                    await this.showGlobalMultipliers(player);
                    break;
                case 1:
                    await this.showSpecialEvents(player);
                    break;
                case 2:
                    await this.showEnergySystem(player);
                    break;
                case 3:
                    await this.showResetStats(player);
                    break;
                case 4:
                    await this.showMainMenu(player);
                    break;
            }
        } catch (error) {
            console.error("Error en showAdvancedConfig:", error);
            player.sendMessage('§cError al mostrar configuración avanzada');
        }
    }

    async showGlobalMultipliers(player) {
        try {
            const form = new ModalFormData();
            form.title('§6Multiplicadores Globales');
            form.slider('Multiplicador de Velocidad (x0.1 - x5.0)', 1, 50, { defaultValue: 10 });
            form.slider('Multiplicador de Cantidad (x0.1 - x5.0)', 1, 50, { defaultValue: 10 });
            form.slider('Multiplicador de Experiencia (x0.1 - x10.0)', 1, 100, { defaultValue: 10 });
            form.toggle('Activar Multiplicadores', { defaultValue: false });
            const response = await form.show(player);
            if (!response.canceled) {
                const [speedInt, amountInt, expInt, activeToggle] = response.formValues;
                const converted = [speedInt / 10, amountInt / 10, expInt / 10, Boolean(activeToggle)];
                this.uiLogic.updateGlobalMultipliers(converted);
                player.sendMessage('§aMultiplicadores actualizados');
            }
            await this.showAdvancedConfig(player);
        } catch (error) {
            console.error("Error en showGlobalMultipliers:", error);
            player.sendMessage('§cError al mostrar multiplicadores globales');
        }
    }

    async showSpecialEvents(player) {
        try {
            const form = new ActionFormData()
                .title('§6Eventos Especiales')
                .body('§7Gestiona eventos temporales:')
                .button('§2Evento 2x Producción', 'textures/items/diamond')
                .button('§3Evento Velocidad +50%', 'textures/items/clock')
                .button('§5Evento Bonificación', 'textures/items/emerald')
                .button('§4Desactivar Eventos', 'textures/items/barrier')
                .button('§8Volver', 'textures/items/arrow');
            const response = await form.show(player);
            if (response.canceled || response.selection === undefined) return;
            if (response.selection < 4) {
                this.uiLogic.activateEvent(response.selection);
                player.sendMessage('§aEvento activado');
            }
            await this.showAdvancedConfig(player);
        } catch (error) {
            console.error("Error en showSpecialEvents:", error);
            player.sendMessage('§cError al mostrar eventos especiales');
        }
    }

    async showEnergySystem(player) {
        try {
            const form = new ModalFormData();
            form.title('§6Sistema de Energía');
            form.toggle('Activar Sistema de Energía', { defaultValue: false });
            form.slider('Energía Máxima por Gen', 10, 1000, { defaultValue: 100 });
            form.slider('Regeneración de Energía (x0.1 - x10.0)', 1, 100, { defaultValue: 10 });
            form.slider('Consumo por Generación', 1, 50, { defaultValue: 10 });
            const response = await form.show(player);
            if (!response.canceled) {
                const [activeToggle, energyMax, regenInt, consumption] = response.formValues;
                const regen = regenInt / 10;
                this.uiLogic.updateEnergySystem([Boolean(activeToggle), energyMax, regen, consumption]);
                player.sendMessage('§aSistema de energía actualizado');
            }
            await this.showAdvancedConfig(player);
        } catch (error) {
            console.error("Error en showEnergySystem:", error);
            player.sendMessage('§cError al mostrar sistema de energía');
        }
    }

    async showResetStats(player) {
        try {
            const form = new MessageFormData()
                .title('§4Resetear Estadísticas')
                .body('§c¡ADVERTENCIA!\n\n§7Esta acción eliminará todas las estadísticas globales y no se puede deshacer.')
                .button1('§4Confirmar Reset')
                .button2('§2Cancelar');
            const response = await form.show(player);
            if (!response.canceled && response.selection === 0) {
                this.uiLogic.resetAllStats();
                player.sendMessage('§aEstadísticas reseteadas exitosamente');
            }
            await this.showAdvancedConfig(player);
        } catch (error) {
            console.error("Error en showResetStats:", error);
            player.sendMessage('§cError al mostrar confirmación de reset');
        }
    }
}