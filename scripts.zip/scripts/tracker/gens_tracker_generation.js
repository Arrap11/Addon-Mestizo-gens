import { world, system } from '@minecraft/server';

export class GensTrackerGeneration {
    constructor() {
        this.generationBuffer = [];
        this.batchProcessingId = null;
        this.initializeGenerationTracking();
    }

    initializeGenerationTracking() {
        if (!world.getDynamicProperty('generation_tracking')) {
            const defaultTracking = {
                enabled: true,
                trackItemTypes: true,
                trackRarities: true,
                trackOwners: true,
                trackLocations: false,
                batchSize: 100,
                flushInterval: 30000
            };
            world.setDynamicProperty('generation_tracking', JSON.stringify(defaultTracking));
        }

        this.generationBuffer = [];
        this.startBatchProcessing();
    }

    startBatchProcessing() {
        const config = this.getTrackingConfig();
        const flushIntervalTicks = Math.floor(config.flushInterval / 50);
        
        this.batchProcessingId = system.runInterval(() => {
            this.flushGenerationBuffer();
        }, flushIntervalTicks);
    }

    getTrackingConfig() {
        try {
            return JSON.parse(world.getDynamicProperty('generation_tracking') || '{}');
        } catch {
            return {
                enabled: true,
                trackItemTypes: true,
                trackRarities: true,
                trackOwners: true,
                trackLocations: false,
                batchSize: 100,
                flushInterval: 30000
            };
        }
    }

    recordGeneration(genId, amount) {
        const config = this.getTrackingConfig();
        if (!config.enabled) return;

        const gen = this.getGenData(genId);
        if (!gen) return;

        const generationRecord = {
            genId: genId,
            amount: amount,
            timestamp: Date.now(),
            itemType: config.trackItemTypes ? gen.item : null,
            rarity: config.trackRarities ? gen.rarity : null,
            owner: config.trackOwners ? gen.owner : null,
            location: config.trackLocations ? gen.location : null,
            interval: gen.interval,
            multiplier: gen.multiplier || 1
        };

        this.generationBuffer.push(generationRecord);

        if (this.generationBuffer.length >= config.batchSize) {
            this.flushGenerationBuffer();
        }

        this.updateGenerationCounters(gen, amount);
        this.updateItemTypeStats(gen.item, amount);
        this.updateRarityStats(gen.rarity, amount);
        this.updateOwnerStats(gen.owner, amount);
    }

    flushGenerationBuffer() {
        if (this.generationBuffer.length === 0) return;

        const existingData = this.getStoredGenerations();
        const newData = existingData.concat(this.generationBuffer);

        const maxEntries = 50000;
        if (newData.length > maxEntries) {
            newData.splice(0, newData.length - maxEntries);
        }

        world.setDynamicProperty('stored_generations', JSON.stringify(newData));
        this.generationBuffer = [];
    }

    getStoredGenerations() {
        try {
            return JSON.parse(world.getDynamicProperty('stored_generations') || '[]');
        } catch {
            return [];
        }
    }

    getGenData(genId) {
        const allGens = JSON.parse(world.getDynamicProperty('gens_data') || '{}');
        return allGens[genId] || null;
    }

    updateGenerationCounters(gen, amount) {
        const counters = this.getGenerationCounters();
        
        if (!counters[gen.id]) {
            counters[gen.id] = {
                totalGenerations: 0,
                totalItems: 0,
                averagePerGeneration: 0,
                firstGeneration: Date.now(),
                lastGeneration: Date.now(),
                bestStreak: 0,
                currentStreak: 0,
                efficiency: 100
            };
        }

        const counter = counters[gen.id];
        counter.totalGenerations += 1;
        counter.totalItems += amount;
        counter.averagePerGeneration = counter.totalItems / counter.totalGenerations;
        counter.lastGeneration = Date.now();

        const expectedTime = counter.firstGeneration + (counter.totalGenerations * gen.interval);
        const actualTime = Date.now();
        const timeDiff = Math.abs(actualTime - expectedTime);
        
        if (timeDiff <= gen.interval * 0.1) {
            counter.currentStreak += 1;
            counter.bestStreak = Math.max(counter.bestStreak, counter.currentStreak);
        } else {
            counter.currentStreak = 0;
        }

        const efficiency = Math.max(0, 100 - (timeDiff / gen.interval * 100));
        counter.efficiency = (counter.efficiency * 0.9) + (efficiency * 0.1);

        this.saveGenerationCounters(counters);
    }

    getGenerationCounters() {
        try {
            return JSON.parse(world.getDynamicProperty('generation_counters') || '{}');
        } catch {
            return {};
        }
    }

    saveGenerationCounters(counters) {
        world.setDynamicProperty('generation_counters', JSON.stringify(counters));
    }

    updateItemTypeStats(itemType, amount) {
        const stats = this.getItemTypeStats();
        
        if (!stats[itemType]) {
            stats[itemType] = {
                totalGenerated: 0,
                generationCount: 0,
                averagePerGeneration: 0,
                firstSeen: Date.now(),
                lastSeen: Date.now()
            };
        }

        const itemStats = stats[itemType];
        itemStats.totalGenerated += amount;
        itemStats.generationCount += 1;
        itemStats.averagePerGeneration = itemStats.totalGenerated / itemStats.generationCount;
        itemStats.lastSeen = Date.now();

        this.saveItemTypeStats(stats);
    }

    getItemTypeStats() {
        try {
            return JSON.parse(world.getDynamicProperty('item_type_stats') || '{}');
        } catch {
            return {};
        }
    }

    saveItemTypeStats(stats) {
        world.setDynamicProperty('item_type_stats', JSON.stringify(stats));
    }

    updateRarityStats(rarity, amount) {
        const stats = this.getRarityStats();
        
        if (!stats[rarity]) {
            stats[rarity] = {
                totalGenerated: 0,
                generationCount: 0,
                averagePerGeneration: 0,
                activeGens: 0
            };
        }

        const rarityStats = stats[rarity];
        rarityStats.totalGenerated += amount;
        rarityStats.generationCount += 1;
        rarityStats.averagePerGeneration = rarityStats.totalGenerated / rarityStats.generationCount;

        this.saveRarityStats(stats);
    }

    getRarityStats() {
        try {
            return JSON.parse(world.getDynamicProperty('rarity_stats') || '{}');
        } catch {
            return {};
        }
    }

    saveRarityStats(stats) {
        world.setDynamicProperty('rarity_stats', JSON.stringify(stats));
    }

    updateOwnerStats(owner, amount) {
        const stats = this.getOwnerStats();
        
        if (!stats[owner]) {
            stats[owner] = {
                totalGenerated: 0,
                generationCount: 0,
                activeGens: 0,
                totalValue: 0,
                averagePerGeneration: 0,
                firstActivity: Date.now(),
                lastActivity: Date.now()
            };
        }

        const ownerStats = stats[owner];
        ownerStats.totalGenerated += amount;
        ownerStats.generationCount += 1;
        ownerStats.averagePerGeneration = ownerStats.totalGenerated / ownerStats.generationCount;
        ownerStats.lastActivity = Date.now();

        this.saveOwnerStats(stats);
    }

    getOwnerStats() {
        try {
            return JSON.parse(world.getDynamicProperty('owner_stats') || '{}');
        } catch {
            return {};
        }
    }

    saveOwnerStats(stats) {
        world.setDynamicProperty('owner_stats', JSON.stringify(stats));
    }

    getGenerationsInTimeframe(startTime, endTime, genId = null) {
        const storedGenerations = this.getStoredGenerations();
        
        return storedGenerations.filter(gen => {
            const inTimeframe = gen.timestamp >= startTime && gen.timestamp <= endTime;
            const matchesGen = genId ? gen.genId === genId : true;
            return inTimeframe && matchesGen;
        });
    }

    getGenerationRate(genId, timeframe = 3600000) {
        const endTime = Date.now();
        const startTime = endTime - timeframe;
        
        const generations = this.getGenerationsInTimeframe(startTime, endTime, genId);
        const totalItems = generations.reduce((sum, gen) => sum + gen.amount, 0);
        const hoursInTimeframe = timeframe / 3600000;
        
        return {
            generationsPerHour: generations.length / hoursInTimeframe,
            itemsPerHour: totalItems / hoursInTimeframe,
            averageItemsPerGeneration: generations.length > 0 ? totalItems / generations.length : 0
        };
    }

    getTopGenerators(metric = 'totalItems', timeframe = null, limit = 10) {
        let generations = this.getStoredGenerations();
        
        if (timeframe) {
            const startTime = Date.now() - timeframe;
            generations = generations.filter(gen => gen.timestamp >= startTime);
        }

        const genStats = {};
        generations.forEach(gen => {
            if (!genStats[gen.genId]) {
                genStats[gen.genId] = {
                    genId: gen.genId,
                    totalItems: 0,
                    totalGenerations: 0,
                    averageItems: 0,
                    owner: gen.owner,
                    itemType: gen.itemType,
                    rarity: gen.rarity
                };
            }
            
            genStats[gen.genId].totalItems += gen.amount;
            genStats[gen.genId].totalGenerations += 1;
        });

        Object.values(genStats).forEach(stats => {
            stats.averageItems = stats.totalGenerations > 0 ? 
                stats.totalItems / stats.totalGenerations : 0;
        });

        return Object.values(genStats)
            .sort((a, b) => b[metric] - a[metric])
            .slice(0, limit);
    }

    getGenerationHeatmap(genId, days = 30) {
        const endTime = Date.now();
        const startTime = endTime - (days * 24 * 60 * 60 * 1000);
        
        const generations = this.getGenerationsInTimeframe(startTime, endTime, genId);
        const heatmap = {};

        generations.forEach(gen => {
            const hour = new Date(gen.timestamp).getHours();
            const day = Math.floor((gen.timestamp - startTime) / (24 * 60 * 60 * 1000));
            
            if (!heatmap[day]) heatmap[day] = {};
            if (!heatmap[day][hour]) heatmap[day][hour] = 0;
            
            heatmap[day][hour] += gen.amount;
        });

        return heatmap;
    }

    predictNextGeneration(genId) {
        const counter = this.getGenerationCounters()[genId];
        if (!counter) return null;

        const gen = this.getGenData(genId);
        if (!gen) return null;

        const timeSinceLastGeneration = Date.now() - counter.lastGeneration;
        const timeUntilNext = Math.max(0, gen.interval - timeSinceLastGeneration);

        const predictedTime = Date.now() + timeUntilNext;
        const confidence = Math.min(100, counter.efficiency);

        return {
            predictedTime: predictedTime,
            timeUntilNext: timeUntilNext,
            confidence: confidence,
            expectedAmount: gen.amount * (gen.multiplier || 1)
        };
    }

    analyzeGenerationPatterns(genId, days = 14) {
        const endTime = Date.now();
        const startTime = endTime - (days * 24 * 60 * 60 * 1000);
        
        const generations = this.getGenerationsInTimeframe(startTime, endTime, genId);
        
        if (generations.length < 10) {
            return { error: 'Insufficient data for pattern analysis' };
        }

        const intervals = [];
        for (let i = 1; i < generations.length; i++) {
            intervals.push(generations[i].timestamp - generations[i - 1].timestamp);
        }

        const averageInterval = intervals.reduce((sum, interval) => sum + interval, 0) / intervals.length;
        const standardDeviation = Math.sqrt(
            intervals.reduce((sum, interval) => sum + Math.pow(interval - averageInterval, 2), 0) / intervals.length
        );

        const consistency = 100 - ((standardDeviation / averageInterval) * 100);
        
        const hourlyDistribution = {};
        generations.forEach(gen => {
            const hour = new Date(gen.timestamp).getHours();
            hourlyDistribution[hour] = (hourlyDistribution[hour] || 0) + 1;
        });

        const peakHour = Object.entries(hourlyDistribution)
            .sort(([,a], [,b]) => b - a)[0];

        return {
            averageInterval: Math.round(averageInterval),
            consistency: Math.round(consistency * 100) / 100,
            totalGenerations: generations.length,
            peakHour: peakHour ? parseInt(peakHour[0]) : null,
            regularityScore: Math.min(100, consistency * (generations.length / 100))
        };
    }

    exportGenerationData(genId = null, format = 'json') {
        const generations = genId ? 
            this.getStoredGenerations().filter(gen => gen.genId === genId) :
            this.getStoredGenerations();

        if (format === 'csv') {
            return this.convertToCSV(generations);
        }

        return {
            totalRecords: generations.length,
            exportTime: Date.now(),
            data: generations
        };
    }

    convertToCSV(generations) {
        if (generations.length === 0) return '';

        const headers = Object.keys(generations[0]).join(',');
        const rows = generations.map(gen => 
            Object.values(gen).map(value => 
                typeof value === 'string' ? `"${value}"` : value
            ).join(',')
        );

        return [headers, ...rows].join('\n');
    }

    cleanupGenerationData(daysToKeep = 30) {
        const cutoffTime = Date.now() - (daysToKeep * 24 * 60 * 60 * 1000);
        const storedGenerations = this.getStoredGenerations();
        
        const filteredGenerations = storedGenerations.filter(gen => gen.timestamp >= cutoffTime);
        
        if (filteredGenerations.length !== storedGenerations.length) {
            world.setDynamicProperty('stored_generations', JSON.stringify(filteredGenerations));
            return storedGenerations.length - filteredGenerations.length;
        }
        
        return 0;
    }
}